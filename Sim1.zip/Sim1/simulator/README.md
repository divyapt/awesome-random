# simulator-service
Repo for converting the EFE simulator service apis to Spring MVC


![EFE Nextgen](ngassets/efeng.png?raw=true)

[![Build Status](https://pub-bu-ctg-jenkins.prod1-ibp.a.intuit.com/jenkins/buildStatus/buildIcon?job=CTG/EFE/SIMULATOR/simulator-branch-ci)](https://pub-bu-ctg-jenkins.prod1-ibp.a.intuit.com/jenkins/job/CTG/job/EFE/job/SIMULATOR/job/simulator-branch-ci/)
[![Code Coverage](https://pub-bu-ctg-jenkins.prod1-ibp.a.intuit.com/jenkins/buildStatus/coverageIcon?job=CTG/EFE/SIMULATOR/simulator-branch-ci)](https://pub-bu-ctg-jenkins.prod1-ibp.a.intuit.com/jenkins/job/CTG/job/EFE/job/SIMULATOR/job/simulator-branch-ci/)
[![Test Status](https://pub-bu-ctg-jenkins.prod1-ibp.a.intuit.com/jenkins/buildStatus/testIcon?job=CTG/EFE/SIMULATOR/simulator-branch-ci)](https://pub-bu-ctg-jenkins.prod1-ibp.a.intuit.com/jenkins/job/CTG/job/EFE/job/SIMULATOR/job/simulator-branch-ci/)

Latest Snapshot: [![Latest Snapshot](https://pub-bu-ctg-jenkins.prod1-ibp.a.intuit.com/jenkins/buildStatus/buildDescriptionIcon?job=CTG/EFE/SIMULATOR/simulator-branch-ci)](https://pub-bu-ctg-jenkins.prod1-ibp.a.intuit.com/jenkins/job/CTG/job/EFE/job/SIMULATOR/job/simulator-branch-ci)

Latest Release: [![Latest Release](https://pub-bu-ctg-jenkins.prod1-ibp.a.intuit.com/jenkins/buildStatus/buildDescriptionIcon?job=CTG/EFE/SIMULATOR/simulator-branch-release)](https://pub-bu-ctg-jenkins.prod1-ibp.a.intuit.com/jenkins/job/CTG/job/EFE/job/SIMULATOR/job/simulator-branch-release)

## Methodology
The goal is to migrate as much of the EFE simulator service to Spring while also sharing the business-logic codebase with mainline EFE to avoid code duplication.  Current dependencies on mainline EFE can be found in the pom.xml, but in general they are limited to `efe-common`, `efe-mpc` and `efe-sim-code`.

## How to Build/Start
In the root of the project:
```
mvn compile package spring-boot:run -Dspring.profiles.active=it_local
```

OR

```
mvn compile package spring-boot:run -Dspring.profiles.active=pr_local
```

This command will build and start the Spring server, it by default binds to port 8080, this can be changed in the application.properties

Note: There are dependencies on the mainline EFE repository, if you do not have a workspace with EFE included, you can use the script provided in the repo.  Changes to the main EFE repo have been made to enable some functions to work. If you are getting build errors, try updating and building the latest version of mainline EFE.  A helper script is provided to help automate this process

## Running in Eclipse
Configure a Spring Boot App run profile that matches/is similar to this screenshot:
![Eclipse Run Config](ngassets/eclipse.png?raw=true)

## Running in IntelliJ
Configure an IntelliJ Spring Boot Configuration matching/similar to this screenshot:
![IntelliJ Run Config](ngassets/intellij.png?raw=true)

## Dockerization
The new meso-services are able to be built and ran in docker. This is in service of managing dependent services and quick developer setup. In order to run the meso-frontend as a docker image, the following prereqs must be fulfilled.

- Docker must be installed. Find instructions [here](https://docs.docker.com/docker-for-mac/install/) on how to do so or use homebrew with the following command:
```
brew cask install docker
```

- You will also need to be logged in to artifactory. To do so, go to https://artifact.intuit.com and log in. Click on your email address in the top right and if you don't have one, generate a token. Once you have one, copy it to your clipboard and in a terminal window run `docker login docker.artifactory.a.intuit.com` providing your email address as the username and your token as the password.
- Certain environment variables must be set locally. We recommend exporting them from your bash config/profile. They are: 
    - LOCAL_IP=$(ifconfig | sed -En 's/127.0.0.1//;s/.*inet (addr:)?(([0-9]*\.){3}[0-9]*).*/\2/p' | head -n 1)
    - NAMESPACE=it OR pr (it is default)

To run the filer-service as a docker image, simply build the image using `mvn install dockerfile:build` and execute the `docker_run.sh` script found at the root of the filer-service project.

## Other Notes

