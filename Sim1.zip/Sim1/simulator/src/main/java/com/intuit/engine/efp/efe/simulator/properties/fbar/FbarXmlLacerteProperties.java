package com.intuit.engine.efp.efe.simulator.properties.fbar;

import com.intuit.engine.efp.efe.simulator.properties.CommonProperties;
import com.intuit.engine.efp.efe.simulator.properties.FtpProperties;
import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value={"classpath:simulator.properties" })
public class FbarXmlLacerteProperties implements CommonProperties {

    @Autowired
    public FbarXmlLacerteFtpProperties fbarXmlLacerteFtpProperties;


    @Autowired
    public FbarXmlLacerteSiteProperties fbarXmlLacerteSiteProperties;

    @Override
    public FtpProperties getFtpProperties() {
        return fbarXmlLacerteFtpProperties;
    }

    @Override
    public SiteProperties getSiteProperties() {
        return fbarXmlLacerteSiteProperties;
    }
}
