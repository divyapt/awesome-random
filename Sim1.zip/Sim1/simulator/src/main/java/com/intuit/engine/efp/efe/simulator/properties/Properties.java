package com.intuit.engine.efp.efe.simulator.properties;

import com.intuit.engine.efp.efe.simulator.properties.california.mef.CaMefApdProperties;
import com.intuit.engine.efp.efe.simulator.properties.california.mef.CaMefLacerteProperties;
import com.intuit.engine.efp.efe.simulator.properties.california.mef.CaMefProProperties;
import com.intuit.engine.efp.efe.simulator.properties.california.mef.CaMefProperties;
import com.intuit.engine.efp.efe.simulator.properties.california.mef.bit.CaMefBitApdProperties;
import com.intuit.engine.efp.efe.simulator.properties.california.mef.bit.CaMefBitLacerteProperties;
import com.intuit.engine.efp.efe.simulator.properties.california.mef.bit.CaMefBitProProperties;
import com.intuit.engine.efp.efe.simulator.properties.california.mef.bit.CaMefBitProperties;
import com.intuit.engine.efp.efe.simulator.properties.fbar.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Properties {

    // Autoworing all Fbar properties
    @Autowired
    public FbarApdProperties fbarApdProperties;

    @Autowired
    public FbarLacerteProperties fbarLacerteProperties;

    @Autowired
    public FbarProProperties fbarProProperties;

    @Autowired
    public FbarXmlApdProperties fbarXmlApdProperties;

    @Autowired
    public FbarXmlProProperties fbarXmlProProperties;

    @Autowired
    public FbarXmlLacerteProperties fbarXmlLacerteProperties;

    // Autoworing all CaMef properties
    @Autowired
    public CaMefApdProperties caMefApdProperties;

    @Autowired
    public CaMefLacerteProperties caMefLacerteProperties;

    @Autowired
    public CaMefProProperties caMefProProperties;

    @Autowired
    public CaMefProperties caMefProperties;

    // Autoworing all CaMef Bit properties
    @Autowired
    public CaMefBitApdProperties caMefBitApdProperties;

    @Autowired
    public CaMefBitLacerteProperties caMefBitLacerteProperties;

    @Autowired
    public CaMefBitProProperties caMefBitProProperties;

    @Autowired
    public CaMefBitProperties caMefBitProperties;

}
