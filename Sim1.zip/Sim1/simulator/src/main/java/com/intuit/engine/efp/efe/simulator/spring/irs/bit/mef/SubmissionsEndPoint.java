package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;


import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.*;
import com.intuit.engine.efp.efe.common.IOUtils;
import com.intuit.engine.efp.efe.simulator.SimUtils;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.*;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.payloadparsers.Irs1040PayloadParser;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.payloadparsers.IrsPayloadParser;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.payloadparsers.PayloadParser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBElement;
import java.util.Map;

@Endpoint
public class SubmissionsEndPoint {

    private static final String TRANSMITTER_NAMESPACE = "http://www.irs.gov/a2a/mef/MeFTransmitterServiceMTOM.xsd";
    private static final String MEFHEADER_NAME = "{http://www.irs.gov/a2a/mef/MeFHeader.xsd}MeFHeader";
    private Log log = LogFactory.getLog(getClass());


    /**
     * @see SendSubmissionsService#sendSubmissions(SendSubmissionsRequestType)
     */

    @PayloadRoot(namespace = TRANSMITTER_NAMESPACE, localPart = "SendSubmissionsRequest")
    @ResponsePayload
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT)
    public JAXBElement<SendSubmissionsResponseType> sendSubmissions(@RequestPayload SendSubmissionsRequestType sendSubmissionsRequest,@SoapHeader(MEFHEADER_NAME) MeFHeaderType meFHeader) throws ErrorExceptionDetail {
        {

            log.debug("MEF simulator: sendSubmissions called.");

            String etinOfSender = meFHeader.getETIN();

            SimUtils.soapFaultRequestCheck("SendSubmissionsService.sendSubmissions", meFHeader.getETIN(), SimUtils.SEND_SUBMISSIONS_SOAP_FAULT_ETIN);

            try {
                RequestAttributes attribs = RequestContextHolder.getRequestAttributes();
                HttpServletRequest request = ((ServletRequestAttributes) attribs).getRequest();
                AgencyTimingEmulator agencyTimingEmulator = new AgencyTimingEmulator(log);
                agencyTimingEmulator.processDelayRequest(request);
                Base64Binary attachment = sendSubmissionsRequest.getSubmissionsAttMTOM();
                if (attachment == null) {
                    throw new RuntimeException("SendSubmissionsService - null attachment");
                }
                byte[] attachmentData = attachment.getValue();
                SubmissionParser parser = new SubmissionParser(sendSubmissionsRequest, attachmentData);
                parser.execute();

                // generate and store the level 2 acknowledgements and Receipts
                AcknowledgementCache acks = AcknowledgementCache.getInstance();
                ReceiptListZipFile receipts = new ReceiptListZipFile();
                boolean failTransmission = false;
                for (Map.Entry<String, ContainerZipFile.SubmissionZipFile> submission : parser.getSubmissions().entrySet()) {
                    String submissionId = submission.getKey();
                    Acknowledgement ack = new Acknowledgement(submissionId, submission.getValue());

                    PayloadParser parser1 = submission.getValue().getPayloadParser();

                    if (parser1 instanceof Irs1040PayloadParser)
                        failTransmission = ((IrsPayloadParser) parser1).failTransmission();

                    acks.add(ack, etinOfSender);
                    receipts.add(submissionId);
                }

                // return a Receipts zip file
                byte[] receiptData = receipts.toZipFile();
                Base64Binary receiptAttachment = new Base64Binary();
                receiptAttachment.setValue(receiptData);
                SendSubmissionsResponseType response = new SendSubmissionsResponseType();
                response.setSubmissionRcptListAttMTOM(receiptAttachment);

                TransmissionHeaderValidator.addFakeNotificationMessageToHeader(meFHeader);
                if (failTransmission)
                    throw new Exception("-DAFT- -> Doing A Fail Transmission");
                // for now always return successfully
                ObjectFactory factory = new ObjectFactory();
                JAXBElement<SendSubmissionsResponseType> jaxbElement = factory.createSendSubmissionsResponse(response);

                return jaxbElement;
            } catch (RuntimeException e) {
                // Probably a parsing error - possibly legitimate test case
                log.error("Error during SendSubmissions operation", e);
                throw toMeFException(e);
            } catch (Exception e) {
                // unexpected error - could be bug in simulator
                log.error("Unexepected Error during SendSubmissions operation", e);
                throw toMeFException(e);
            }
        }

    }

    /**
     * Wrap runtime exception in a MeFException
     *
     * @param ex RuntimeException
     * @return an equivalent MeFException
     */
    private ErrorExceptionDetail toMeFException(Exception ex) {
        ErrorExceptionDetailType faultInfo = new ErrorExceptionDetailType();
        faultInfo.setErrorMessageCd(ex.getMessage());  //.setErrorCode(ex.getMessage());
        faultInfo.setErrorMessageTxt(new String(IOUtils.toByteArray(ex)));  //.setErrorMessage(new String(IOUtils.toByteArray(ex)));
        return new ErrorExceptionDetail("Problem during SendSubmissions", faultInfo, ex);
    }


}
