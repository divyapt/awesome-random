package com.intuit.engine.efp.efe.simulator.properties;

/**
 * FTP login specific properties
 */
public interface FtpProperties {

    public String getUsername();
    public void setUsername(String inUsername);

    public String getPassword();
    public void setPassword(String inPassword);

    public String getHost();
    public void setHost(String inHost);

    public Integer getPort() ;
    public void setPort(Integer inPort);

}
