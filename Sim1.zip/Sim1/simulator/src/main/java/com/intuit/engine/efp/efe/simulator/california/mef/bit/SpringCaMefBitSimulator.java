package com.intuit.engine.efp.efe.simulator.california.mef.bit;

import com.intuit.engine.efp.efe.common.EfeRuntimeException;
import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.SpringDaemonHandler;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.SpringFtpHandler;
import com.intuit.engine.efp.efe.simulator.properties.CommonProperties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Spring hook for CA MEF BIT Simulator.
 */
public class SpringCaMefBitSimulator extends CaMefBitSimulator {

    private static final Log log = LogFactory.getLog(com.intuit.engine.efp.efe.simulator.california.mef.bit.SpringCaMefBitSimulator.class);


    private CommonProperties mefBitProperties;

    public SpringCaMefBitSimulator() {

    }

    public SpringCaMefBitSimulator(Simulator mgmt) {
        addManagement(mgmt);
    }


    public void addManagement(Simulator mgmt) {

        management = mgmt;
        handler = new SpringFtpHandler(new SpringDaemonHandler(this), mefBitProperties.getFtpProperties());
        handler.setLog(log);
    }

    public void init() {

        ((SpringFtpHandler)handler).init(mefBitProperties.getSiteProperties(), management);
        try {
            ((SpringFtpHandler)handler).createDir(mefBitProperties.getSiteProperties().getUploadDirectory());
            ((SpringFtpHandler)handler).createDir(mefBitProperties.getSiteProperties().getDownloadDirectory());
        } catch (Exception ex) {
            log.error(ex);
            throw new EfeRuntimeException("Failed to create FTP directories for FbarApdSimulator", ex);
        }
    }

    public CommonProperties getMefBitProperties() {
        return mefBitProperties;
    }

    public void setMefBitProperties(CommonProperties mefBitProperties) {
        this.mefBitProperties = mefBitProperties;
    }


}
