package com.intuit.engine.efp.efe.simulator;

import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.ComponentScan;

import ch.qos.logback.classic.BasicConfigurator;
import ch.qos.logback.classic.LoggerContext;


@ServletComponentScan
@SpringBootApplication
@ComponentScan(basePackages = {
		"com.intuit.engine.efp.efe.spring.common.util",
		"com.intuit.engine.efp.efe.spring.common",
		"com.intuit.engine.efp.efe.spring.configuration",
		"com.intuit.engine.efp.efe.spring.configuration.persistence",
		"com.intuit.engine.efp.efe.mpc.persistence",
		"com.intuit.engine.efp.efe.simulator.properties",
		"com.intuit.engine.efp.efe.simulator.configuration",
		"com.intuit.engine.efp.efe.simulator.sbbt",
		"com.intuit.engine.efp.efe.simulator.rc",
		"com.intuit.engine.efp.efe.simulator.ra",
		"com.intuit.engine.efp.efe.simulator.fbar",
		"com.intuit.engine.efp.efe.simulator.california.mef",
		"com.intuit.engine.efp.efe.simulator.california.mef.bit",
		"com.intuit.engine.efp.efe.simulator.fsb",
		"com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef"
}
)
public class SimulatorLauncher {
    public static void main(String[] args) {
        new BasicConfigurator().configure((LoggerContext) LoggerFactory.getILoggerFactory());
        SpringApplication.run(SimulatorLauncher.class, args);
    }
}
