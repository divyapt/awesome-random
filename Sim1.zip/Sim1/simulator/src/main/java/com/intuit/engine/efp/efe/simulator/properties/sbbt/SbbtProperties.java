package com.intuit.engine.efp.efe.simulator.properties.sbbt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;

@Component
//@ConfigurationProperties(prefix = "simulator.sbbt.iit")
@PropertySource(value={"classpath:simulator.properties" })
public class SbbtProperties {
    @Nullable
    @Autowired
    public SbbtFtpProperties ftp;

    @Value("${simulator.sbbt.iit.testonly}")
    public String testonly;

    @Value("${simulator.sbbt.iit.polling.freq}")
    public String pollingFrequency;

    @Nullable
    @Autowired
    public PerProperties per;

    @Nullable
    @Autowired
    public ProProperties pro;
}
