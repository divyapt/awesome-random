package com.intuit.engine.efp.efe.simulator.properties;

/**
 * Ftp common properties.
 */
public interface CommonProperties {

    public FtpProperties getFtpProperties();

    public SiteProperties getSiteProperties();
}
