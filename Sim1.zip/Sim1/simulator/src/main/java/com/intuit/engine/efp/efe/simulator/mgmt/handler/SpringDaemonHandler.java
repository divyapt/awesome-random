package com.intuit.engine.efp.efe.simulator.mgmt.handler;

import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import org.bouncycastle.openpgp.PGPException;

import java.util.ArrayList;
import java.util.List;

/**
 * A base handler that will periodically call the getSubmissions chain of
 * handlers, and if any submissions are found, notify the listener to
 * process sed submissions.
 * <p>
 * <b>Configuration:</b><p>
 * The default polling is 5 seconds. This is configurable by adding the
 * following init-param to the web.xml:
 * 
 * <init-param>
 *   <param-name>polling.freq</param-name>
 *   <param-value>15000</param-value>
 * </init-param>
 * 
 */
public class SpringDaemonHandler extends SimHandler implements SpringSimHandler {
    private long delay = 5000;
    private WorkerThread worker;
    private SubmissionListener listener;
    
    public SpringDaemonHandler(SubmissionListener l) {
        this.listener = l;
    }
    
    /**
     * Called when servlet is first loaded. The web.xml should tell the
     * servlet to load-on-startup so that this will be invoked immediately.
     */
    public void init(SiteProperties config, Simulator mgmt) {
        try {
            delay = Long.parseLong(config.getPollingFrequency());
        } catch(NumberFormatException nfe) {
            // Just use the default
        }
        mgmt.setServerStatus("Polling Frequency", Integer.toString((int)(delay/1000.0)));
            
        worker = new WorkerThread();
        worker.start();
    }
    
    public void destroy() {
        worker.killThread();
        super.destroy();
    }
    
    /**
     * Calls the SimHandler chain to retrieve the submission, then calls
     * the listener to update that there are new files to process.
     */
    private void doWork() {
        log.debug("getSubmissions start");
        try {
            List<Submission> files = new ArrayList<Submission>();
            getSubmissions(files);
            if (files.size() > 0) {
                if (listener != null) {
                    listener.processSubmissions(files);
                }
            }
            log.debug("getSubmissions end");
        } catch(PGPException pgp) {
            if (pgp.getUnderlyingException() != null) {
                log.error("PGP Exception\n", pgp.getUnderlyingException());
            } else {
                log.error("PGP Exception\n", pgp);
            }
            
        } catch (Throwable t) {
            log.error("Failed to process files\n", t);
        }
    }
    
    private class WorkerThread extends Thread {
        private boolean isRunning = true;
        
        public synchronized void killThread() {
            isRunning = false;
            interrupt();
        }
        public void run() {
            try {
                boolean run = true;
                
                while(run) {
                    Thread.sleep(delay);
                    doWork();
                    synchronized(this) {
                        run = isRunning;
                    }
                }
            }catch(InterruptedException ie) {
                log.info("Thread stopped");
            }
        }
    }
    
    
}
