package com.intuit.engine.efp.efe.simulator.spring;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;

import org.springframework.core.MethodParameter;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.util.Assert;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.adapter.method.MethodArgumentResolver;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;
import org.springframework.xml.namespace.QNameUtils;

public class Jaxb2SoapHeaderElementMethodArgumentResolver implements MethodArgumentResolver {

    private final Jaxb2Marshaller marshaller;

    public Jaxb2SoapHeaderElementMethodArgumentResolver(Jaxb2Marshaller marshaller) {
        this.marshaller = marshaller;
    }

    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        SoapHeader soapHeader = parameter.getParameterAnnotation(SoapHeader.class);
        if (soapHeader == null) {
            return false;
        }

        Class<?> parameterType = parameter.getParameterType();
        return isJaxbType(parameterType) || (List.class.equals(parameterType) && isJaxbType(getListTypeArgument(parameter)));
    }

    private Class<?> getListTypeArgument(MethodParameter parameter) {
        Type genericType = parameter.getGenericParameterType();
        if (genericType instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType) genericType;
            Type[] typeArguments = parameterizedType.getActualTypeArguments();
            if (typeArguments.length == 1 && typeArguments[0] instanceof Class) {
                return (Class<?>) typeArguments[0];
            }
        }
        return null;
    }

    private boolean isJaxbType(Class<?> domType) {
        return domType != null && domType.isAnnotationPresent(XmlType.class);
    }

    @Override
    public Object resolveArgument(MessageContext messageContext, MethodParameter parameter) throws Exception {
        Assert.isInstanceOf(SoapMessage.class, messageContext.getRequest());
        SoapMessage request = (SoapMessage) messageContext.getRequest();
        org.springframework.ws.soap.SoapHeader soapHeader = request.getSoapHeader();

        String paramValue = parameter.getParameterAnnotation(SoapHeader.class).value();

        Assert.isTrue(QNameUtils.validateQName(paramValue), "Invalid header qualified name [" + paramValue + "]. " +
                "QName must be of the form '{namespace}localPart'.");

        QName qname = QName.valueOf(paramValue);

        Class<?> parameterType = parameter.getParameterType();

        if (isJaxbType(parameterType)) {
            return extractSoapHeader(qname, soapHeader, parameterType);
        }
        else if (List.class.equals(parameterType)) {
            return extractSoapHeaderList(qname, soapHeader, getListTypeArgument(parameter));
        }
        // should not happen
        throw new UnsupportedOperationException();
    }

    private <T> T unmarshal(Source source, Class<T> domType) {
        return domType.cast(((JAXBElement<?>) marshaller.unmarshal(source)).getValue());
    }

    private <T> T extractSoapHeader(QName qname, org.springframework.ws.soap.SoapHeader soapHeader, Class<T> domType) {
        Iterator<SoapHeaderElement> elements = soapHeader.examineAllHeaderElements();
        while (elements.hasNext()) {
            SoapHeaderElement e = elements.next();
            if (e.getName().equals(qname)) {
                return unmarshal(e.getSource(), domType);
            }
        }
        return null;
    }

    private <T> List<T> extractSoapHeaderList(QName qname, org.springframework.ws.soap.SoapHeader soapHeader, Class<T> domType) {
        List<T> result = new ArrayList<>();
        Iterator<SoapHeaderElement> elements = soapHeader.examineAllHeaderElements();
        while (elements.hasNext()) {
            SoapHeaderElement e = elements.next();
            if (e.getName().equals(qname)) {
                result.add(unmarshal(e.getSource(), domType));
            }
        }
        return result;
    }

}
