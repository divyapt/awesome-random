package com.intuit.engine.efp.efe.simulator.rc;

import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.SpringBasicFtpServerHandler;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.SpringDaemonHandler;
import com.intuit.engine.efp.efe.simulator.properties.rc.RcProperties;
import com.intuit.engine.efp.efe.simulator.rc.iit.RcSimulator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Spring hook for RC Simulator.
 */
@Service
public class SpringRcSimulator extends RcSimulator {

    private static final Log log = LogFactory.getLog(SpringRcSimulator.class);

    @Autowired
    protected RcProperties rcProperties;

    public SpringRcSimulator() {

    }

    public SpringRcSimulator(Simulator mgmt) {

        addManagement(mgmt);
    }

    public void addManagement(Simulator mgmt) {
        
        management = mgmt;
        handlerPro = new SpringBasicFtpServerHandler(new SpringDaemonHandler(this), rcProperties.rcFtpProperties);
        handlerPro.setLog(log);
    }

    public void init() {

        ((SpringBasicFtpServerHandler)handlerPro).init(rcProperties.rcSiteProperties, management);
    }

}
