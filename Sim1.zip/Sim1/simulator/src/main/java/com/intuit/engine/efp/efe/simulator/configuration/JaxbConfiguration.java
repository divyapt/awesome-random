package com.intuit.engine.efp.efe.simulator.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.ObjectFactory;

@Configuration
public class JaxbConfiguration {

    @Bean
    public Jaxb2Marshaller jaxb2Marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        // all the classes the context needs to know about
        // might be better to use the ObjectFactory class: marshaller.setClassesToBeBound(ObjectFactory.class)
        marshaller.setPackagesToScan(ObjectFactory.class.getPackage().getName());
        return marshaller;
    }

}
