package com.intuit.engine.efp.efe.simulator.properties.rc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value={"classpath:simulator.properties" })
public class RcProperties {

    @Autowired
    public RcFtpProperties rcFtpProperties;


    @Autowired
    public RcSiteProperties rcSiteProperties;
}
