package com.intuit.engine.efp.efe.simulator.properties.sbbt;

import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;

@Component
//@ConfigurationProperties(prefix = "simulator.sbbt.iit.per")
@PropertySource(value={"classpath:simulator.properties" })
public class PerProperties implements SiteProperties {
    @Value("${simulator.sbbt.iit.per.ftp.upload.dir}")
    protected String uploadDirectory;
    public String getUploadDirectory() { return uploadDirectory; }
    public void setUploadDirectory(String inUploadDirectory) { this.uploadDirectory = inUploadDirectory; }

    @Value("${simulator.sbbt.iit.per.ftp.download.dir}")
    protected String downloadDirectory;
    public String getDownloadDirectory() { return downloadDirectory; }
    public void setDownloadDirectory(String inDownloadDirectory) { this.downloadDirectory = inDownloadDirectory; }

    @Value("${simulator.sbbt.iit.per.ftp.process.dir}")
    protected String processDirectory;
    public String getProcessDirectory() { return processDirectory; }
    public void setProcessDirectory(String inProcessDirectory) { this.processDirectory = inProcessDirectory; }

    @Value("${simulator.sbbt.iit.per.ftp.acks.dir}")
    protected String acksDirectory;
    public String getAcksDirectory() { return acksDirectory; }
    public void setAcksDirectory(String inAcksDirectory) { this.acksDirectory = inAcksDirectory; }

    @Value("${simulator.sbbt.iit.per.ftp.archive.dir}")
    protected String archiveDirectory;
    public String getArchiveDirectory() { return archiveDirectory; }
    public void setArchiveDirectory(String inArchiveDirectory) { this.archiveDirectory = inArchiveDirectory; }

    @Value("${simulator.sbbt.iit.per.ftp.enrollment.dir}")
    protected String enrollmentDirectory;
    public String getEnrollmentDirectory() { return enrollmentDirectory; }
    public void setEnrollmentDirectory(String inEnrollmentDirectory) { this.enrollmentDirectory = inEnrollmentDirectory; }

    @Value("${simulator.sbbt.iit.per.transmitterId}")
    protected String transmitterId;
    public String getTransmitterId() { return transmitterId; }
    public void setTransmitterId(String inTransmitterId) { this.transmitterId = inTransmitterId; }

    @Value("${simulator.sbbt.iit.per.polling.freq}")
    public String pollingFrequency;
    public String getPollingFrequency() { return pollingFrequency; }
    public void setPollingFrequency(String inPollingFrequency) { this.pollingFrequency = inPollingFrequency; }

    @Nullable
    @Autowired
    protected PerBank2Properties perBank2;
    public PerBank2Properties getPerBank2() { return perBank2; }
    public void setPerBank2(PerBank2Properties inPerBank2) { this.perBank2 = inPerBank2; }

    @Nullable
    @Autowired
    protected PerSite2Properties perSite2;
    public PerSite2Properties getPerSite2() { return perSite2; }
    public void setPerSite2(PerSite2Properties inPerSite2) { this.perSite2 = inPerSite2; }

    @Nullable
    @Autowired
    protected PerBank2Site2Properties perBank2Site2;
    public PerBank2Site2Properties getPerBank2Site2() { return perBank2Site2; }
    public void setPerBank2Site2(PerBank2Site2Properties inPerBank2Site2) { this.perBank2Site2 = inPerBank2Site2; }
}
