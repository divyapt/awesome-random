package com.intuit.engine.efp.efe.simulator.sbbt;

import com.intuit.engine.efp.efe.common.EfeRuntimeException;
import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.*;
import com.intuit.engine.efp.efe.simulator.properties.sbbt.SbbtProperties;
import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class SpringSbbtSimulator extends SbbtSimulator {

    private static final Log log = LogFactory.getLog(SpringSbbtSimulator.class);

    @Autowired
    protected SbbtProperties sbbtProperties;

    public SpringSbbtSimulator() {
    }

    public SpringSbbtSimulator(Simulator mgmt) {
        addManagement(mgmt);
    }

    public void addManagement(Simulator mgmt) {
        management = mgmt;
        handlerPer = createFtpHandler();
        handlerPerBank2 = createFtpHandler();
        handlerPerSite2 = createFtpHandler();
        handlerPerBank2Site2 = createFtpHandler();
        handlerPro = createFtpHandler();
        handlerProEnrollment =createFtpHandler();
        handlerProQC = createFtpHandler();
        handlerProQCEnrollment = createFtpHandler();
    }

    public void init() {
        try {

            initializeFtpHandler(handlerPer,sbbtProperties.per);
            initializeFtpHandler(handlerPerBank2,sbbtProperties.per.getPerBank2());
            initializeFtpHandler(handlerPerSite2,sbbtProperties.per.getPerSite2());
            initializeFtpHandler(handlerPerBank2Site2,sbbtProperties.per.getPerBank2Site2());
            initializeFtpHandler(handlerPro,sbbtProperties.pro);
            initializeFtpHandler(handlerProEnrollment,sbbtProperties.pro);
            initializeFtpHandler(handlerProQC,sbbtProperties.pro.getProQc());
            initializeFtpHandler(handlerProQCEnrollment,sbbtProperties.pro.getProQc());


            //create ftp directories for each handler
            createFtpDirectories(handlerPer, sbbtProperties.per);
            perNonEnrollmentUploadDir = sbbtProperties.per.getAcksDirectory();
            perEnrollmentUploadDir = sbbtProperties.per.getEnrollmentDirectory()+"/ACKS";
            handlerPer.createDir(perEnrollmentUploadDir);
            perTransmitterId = sbbtProperties.per.getTransmitterId();

            createFtpDirectories(handlerPerBank2, sbbtProperties.per.getPerBank2());
            perBank2NonEnrollmentUploadDir = sbbtProperties.per.getPerBank2().getAcksDirectory();
            perBank2EnrollmentUploadDir = sbbtProperties.per.getPerBank2().getEnrollmentDirectory()+"/ACKS";
            handlerPerBank2.createDir(perBank2EnrollmentUploadDir);
            perBank2TransmitterId = sbbtProperties.per.getPerBank2().getTransmitterId();

            createFtpDirectories(handlerPerSite2,sbbtProperties.per.getPerSite2());
            perSite2NonEnrollmentUploadDir = sbbtProperties.per.getPerSite2().getAcksDirectory();
            perSite2EnrollmentUploadDir = sbbtProperties.per.getPerSite2().getEnrollmentDirectory()+"/ACKS";
            handlerPerSite2.createDir(perSite2EnrollmentUploadDir);
            perSite2TransmitterId = sbbtProperties.per.getPerSite2().getTransmitterId();

            createFtpDirectories(handlerPerBank2Site2,sbbtProperties.per.getPerBank2Site2());
            perBank2Site2NonEnrollmentUploadDir = sbbtProperties.per.getPerBank2Site2().getAcksDirectory();
            perBank2Site2EnrollmentUploadDir = sbbtProperties.per.getPerBank2Site2().getEnrollmentDirectory()+"/ACKS";
            handlerPerBank2Site2.createDir(perBank2Site2EnrollmentUploadDir);
            perBank2Site2TransmitterId = sbbtProperties.per.getPerBank2Site2().getTransmitterId();

            createFtpDirectories(handlerPro,sbbtProperties.pro);
            createFtpDirectories(handlerProEnrollment,sbbtProperties.pro);
            proNonEnrollmentUploadDir = sbbtProperties.pro.getAcksDirectory();
            proEnrollmentUploadDir = sbbtProperties.pro.getEnrollmentDirectory()+"/ACKS";
            handlerPro.createDir(proEnrollmentUploadDir);
            proTransmitterId = sbbtProperties.pro.getTransmitterId();

            createFtpDirectories(handlerProQC,sbbtProperties.pro.getProQc());
            createFtpDirectories(handlerProQCEnrollment,sbbtProperties.pro.getProQc());
            proQCNonEnrollmentUploadDir = sbbtProperties.pro.getProQc().getAcksDirectory();
            proQCEnrollmentUploadDir = sbbtProperties.pro.getProQc().getEnrollmentDirectory()+"/ACKS";
            handlerProQC.createDir(proQCEnrollmentUploadDir);
            proQCTransmitterId = sbbtProperties.pro.getProQc().getTransmitterId();

        } catch(Exception ex) {
            log.error(ex);
            throw new EfeRuntimeException("Failed to start embedded FTP server", ex);
        }
    }


    /**
     * Create FTP server handler.
     */
    private EmbeddedFtpServerHandler createFtpHandler(){
        SpringBasicFtpServerHandler handler = new SpringBasicFtpServerHandler(new SpringDaemonHandler(this), sbbtProperties.ftp);
        handler.setAppendMode(true);    // SBBT must append to existing records if they have not already been picked up
        handler.setFtpFilter(new ExtensionFtpFilter(".000"));
        handler.setLog(log);
        return handler;
    }

    /**
     * Initialize FTP server handler.
     */
    private void initializeFtpHandler(EmbeddedFtpServerHandler handler, SiteProperties ftpConfig) {
        ((SpringBasicFtpServerHandler)handler).init(ftpConfig, management);
    }

    /**
     * Create the upload, Download, Process, Acks, Archive, Enrollment directories for each Handler.
     * Swap the actual upload/dload directory with acks and process
     * @param handler
     */
    private void createFtpDirectories(EmbeddedFtpServerHandler handler, SiteProperties ftpConfig) throws IOException{
        handler.createDir(ftpConfig.getUploadDirectory());
        handler.createDir(ftpConfig.getDownloadDirectory());
        handler.createDir(ftpConfig.getProcessDirectory());
        handler.createDir(ftpConfig.getAcksDirectory());
        handler.createDir(ftpConfig.getArchiveDirectory());
        handler.createDir(ftpConfig.getEnrollmentDirectory());
        handler.setDloadDir(ftpConfig.getProcessDirectory());
    }
}
