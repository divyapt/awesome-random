package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;

import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.*;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.LogoutService;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.ws.Holder;

@Endpoint
public class LogoutEndPoint {

    private static final String NAMESPACE_URI = "http://www.irs.gov/a2a/mef/MeFMSIServices.xsd";

    private static final String MEFHEADER_NAME = "{http://www.irs.gov/a2a/mef/MeFHeader.xsd}MeFHeader";

    private final LogoutService logoutService;

    public LogoutEndPoint(LogoutService logoutService) {
        this.logoutService = logoutService;
    }

    /**
     * @see LogoutService#logout(Holder, LogoutRequestType)
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "LogoutRequest")
    @ResponsePayload
    public JAXBElement<LogoutResponseType> login(@SoapHeader(MEFHEADER_NAME) MeFHeaderType meFHeader, @RequestPayload LogoutRequestType logout) throws ErrorExceptionDetail {
        LogoutResponseType response = logoutService.logout(new Holder<>(meFHeader),logout);
        return new JAXBElement<>(new QName(NAMESPACE_URI, "LogoutResponse"), LogoutResponseType.class, response);
    }

}
