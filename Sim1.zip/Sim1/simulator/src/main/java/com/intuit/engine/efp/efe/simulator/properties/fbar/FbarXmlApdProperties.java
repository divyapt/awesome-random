package com.intuit.engine.efp.efe.simulator.properties.fbar;

import com.intuit.engine.efp.efe.simulator.properties.CommonProperties;
import com.intuit.engine.efp.efe.simulator.properties.FtpProperties;
import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value={"classpath:simulator.properties" })
public class FbarXmlApdProperties implements CommonProperties {

    @Autowired
    public FbarXmlApdFtpProperties fbarXmlApdFtpProperties;


    @Autowired
    public FbarXmlApdSiteProperties fbarXmlApdSiteProperties;

    @Override
    public FtpProperties getFtpProperties() {
        return fbarXmlApdFtpProperties;
    }

    @Override
    public SiteProperties getSiteProperties() {
        return fbarXmlApdSiteProperties;
    }
}
