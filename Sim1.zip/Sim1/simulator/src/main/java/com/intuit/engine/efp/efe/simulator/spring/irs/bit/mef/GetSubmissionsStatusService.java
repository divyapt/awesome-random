package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;

import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.*;
import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.efileAttachments.StatusRecordList;
import com.intuit.engine.efp.efe.agency.protocol.irs.bit.mef.MeFUtils;
import com.intuit.engine.efp.efe.common.DateTimeUtils;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.Acknowledgement;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.AcknowledgementCache;
import com.intuit.engine.efp.efe.util.ZipWriter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.math.BigInteger;
import java.util.List;

@Endpoint
public class GetSubmissionsStatusService {
    private static final String TRANSMITTER_NAMESPACE = "http://www.irs.gov/a2a/mef/MeFTransmitterServiceMTOM.xsd";
    private static final String MEFHEADER_NAME = "{http://www.irs.gov/a2a/mef/MeFHeader.xsd}MeFHeader";
    private Log log = LogFactory.getLog(getClass());
    ObjectFactory f = new ObjectFactory();

    @PayloadRoot(namespace = TRANSMITTER_NAMESPACE, localPart = "GetSubmissionsStatusResponse")
    @ResponsePayload
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT)
    public JAXBElement<GetSubmissionsStatusResponseType> getSubmissionsStatus(@RequestPayload GetSubmissionsStatusRequestType getSubmissionStatusRequest, @SoapHeader(MEFHEADER_NAME) MeFHeaderType meFHeader) throws
            ErrorExceptionDetail {


        log.debug("MEF simulator: sendSubmissions called.");

        String etinOfSender = meFHeader.getETIN();
        SubmissionIdListType submissionIdList = getSubmissionStatusRequest.getSubmissionIdList();
        List<String> submissionIds = submissionIdList.getSubmissionId();
        log.debug("MeF GetSubmissionsStatus for " + submissionIds);
        AcknowledgementCache.GetAcksResult acksResult = AcknowledgementCache.getInstance().getAcks(submissionIds, etinOfSender);


        GetSubmissionsStatusResponseType responseType = f.createGetSubmissionsStatusResponseType();
        SubmissionErrorListType errorList = responseType.getSubmissionErrorList();
        if (errorList == null) {
            errorList = f.createSubmissionErrorListType();
            responseType.setSubmissionErrorList(errorList);
        }
        List<SubmissionErrorType> errors = errorList.getSubmissionError();
        List<String> missingAcks = acksResult.missingAcks;

        missingAcks.forEach(submissionId -> processMissingAcks(submissionId, errors));

        errorList.setCnt(BigInteger.valueOf(missingAcks.size()));

        responseType.setSubmissionErrorList(errorList);

        com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.efileAttachments.ObjectFactory factory =
                new com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.efileAttachments.ObjectFactory();
        StatusRecordList statusRecordList = factory.createStatusRecordList();
        List<StatusRecordList.StatusRecordGrp> statusRecords = statusRecordList.getStatusRecordGrp();
        List<Acknowledgement> acks = acksResult.acks;

        acks.forEach(ack -> processAckStatus(ack, factory, statusRecords));

        statusRecordList.setCnt(BigInteger.valueOf(acks.size()));

        try {
            byte[] statusRecordData = MeFUtils.marshal(statusRecordList);
            ZipWriter zipWriter = new ZipWriter(true);
            zipWriter.setOldStyle();
            zipWriter.addEntry("/statusrecords.xml", statusRecordData);
            byte[] statusZip = zipWriter.close();
            Base64Binary statusAttachment = new Base64Binary();
            statusAttachment.setValue(statusZip);
            responseType.setStatusRecordListAttMTOM(statusAttachment);
        } catch (JAXBException je) {
            String msg = "Exception marshalling Status Record List" + je;
            log.error(msg, je);
            ErrorExceptionDetailType exceptionType = f.createErrorExceptionDetailType();
            exceptionType.setErrorClassificationCd(ErrorClassificationCdType.SYSTEM_ERROR);
            exceptionType.setErrorMessageTxt(msg);
            exceptionType.setErrorMessageCd("-1");
            throw new ErrorExceptionDetail(msg, exceptionType);
        } catch (IOException ioe) {
            String msg = "IOException zipping Status Record List" + ioe;
            log.error(msg, ioe);
            ErrorExceptionDetailType exceptionType = f.createErrorExceptionDetailType();
            exceptionType.setErrorClassificationCd(ErrorClassificationCdType.SYSTEM_ERROR);
            exceptionType.setErrorMessageTxt(msg);
            exceptionType.setErrorMessageCd("-2");
            throw new ErrorExceptionDetail(msg, exceptionType);
        }
        JAXBElement<GetSubmissionsStatusResponseType> response = f.createGetSubmissionsStatusResponse(responseType);

        return response;

    }

    private void processMissingAcks(String submissionId, List<SubmissionErrorType> errors) {
        SubmissionErrorType error = f.createSubmissionErrorType();
        error.setSubmissionId(submissionId);
        ErrorClassificationDetailType mefError = f.createErrorClassificationDetailType();
        mefError.setErrorMessageTxt("Couldn't find an ack no where, no how, no way!");
        mefError.setErrorClassificationCd(ErrorClassificationCdType2.RESOURCE_UNAVAILABLE);
        mefError.setErrorMessageCd("123456789");
        error.setErrorClassificationDetail(mefError);
        errors.add(error);
        log.debug("MeF GetSubmissionsStatus added missing ack for " + submissionId);
    }

    private void processAckStatus(Acknowledgement ack, com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.efileAttachments.ObjectFactory factory, List<StatusRecordList.StatusRecordGrp> statusRecords) {
        String submissionId = ack.getSubmissionId();
        Boolean isDoneProcessing = ack.isCompletedProcessingYet();
        String status = "Acknowledged";
        if (!isDoneProcessing) {
            status = "Being Processed";
        }
        StatusRecordList.StatusRecordGrp statusRecord = factory.createStatusRecordListStatusRecordGrp();
        statusRecord.setSubmissionId(submissionId);
        statusRecord.setSubmsnStatusAcknowledgementDt(DateTimeUtils.getCurrentXmlDate());
        statusRecord.setSubmissionStatusTxt(status);
        statusRecords.add(statusRecord);
        log.debug("MeF GetSubmissionsStatus added record for " + submissionId);
    }


}
