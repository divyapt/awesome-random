package com.intuit.engine.efp.efe.simulator.configuration;

import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.List;

import javax.annotation.Resource;
import javax.security.auth.callback.CallbackHandler;
import javax.xml.ws.WebServiceContext;

import com.intuit.engine.efp.efe.agency.protocol.irs.bit.mef.ClientSecurityHandler;
import com.intuit.engine.efp.efe.simulator.fbar.SpringFbarSimulator;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.ServerSecurityHandler;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.server.endpoint.adapter.method.MethodArgumentResolver;
import org.springframework.ws.soap.security.xwss.XwsSecurityInterceptor;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.SimpleWsdl11Definition;
import org.springframework.ws.wsdl.wsdl11.Wsdl11Definition;

import com.intuit.engine.efp.efe.simulator.spring.Jaxb2SoapHeaderElementMethodArgumentResolver;

@EnableWs
@Configuration
public class WebServiceConfig extends WsConfigurerAdapter {
    private static final Log log = LogFactory.getLog(WebServiceConfig.class);
    @Autowired
    private Jaxb2Marshaller jaxb2Marshaller;


    @Bean
    public CallbackHandler keyStoreHandler() throws Exception {
        ServerSecurityHandler serverSecurityHandler = new ServerSecurityHandler();
        return serverSecurityHandler;
    }

    @Bean
    public EndpointInterceptor securityInterceptor() throws Exception {
        XwsSecurityInterceptor securityInterceptor = new XwsSecurityInterceptor();
        securityInterceptor.setCallbackHandler(keyStoreHandler());
        securityInterceptor.setPolicyConfiguration(new ClassPathResource("securityPolicy.xml"));
        return securityInterceptor;
    }


    @Override
    public void addInterceptors(List<EndpointInterceptor> interceptors)
    {
        try {
         //  interceptors.add(securityInterceptor());
        } catch (Exception e) {
            log.error("Error while adding interceptors", e);
            throw new RuntimeException("Error while adding interceptors", e);
        }

    }

    @Override
    public void addArgumentResolvers(List<MethodArgumentResolver> argumentResolvers) {
        argumentResolvers.add(new Jaxb2SoapHeaderElementMethodArgumentResolver(jaxb2Marshaller));
    }

    @Bean
    public ServletRegistrationBean messageDispatcherServlet(ApplicationContext applicationContext) {
        MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        applicationContext.getEnvironment();
        servlet.setApplicationContext(applicationContext);
        servlet.setTransformWsdlLocations(true);
        return new ServletRegistrationBean<>(servlet, "/a2a/mef/*");
    }

    @Bean(name = "MeFMSIServices")
    public Wsdl11Definition meFMSIServicesWsdl11Definition() {
        SimpleWsdl11Definition wsdl11Definition = new SimpleWsdl11Definition();
        wsdl11Definition.setWsdl(new ClassPathResource("schema/wsdl/MeFMSIServices.wsdl"));
        return wsdl11Definition;
    }

    @Bean
    public ServletRegistrationBean mefTransmitterDispatcherServlet(ApplicationContext applicationContext) {
        MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        servlet.setApplicationContext(applicationContext);
        servlet.setTransformWsdlLocations(true);
        return new ServletRegistrationBean<>(servlet, "/a2a/mef/mtom/*");
    }

    @Bean(name = "MeTransmitterService")
    public Wsdl11Definition mefTransmitterServiceWsdl11Definition() {
        SimpleWsdl11Definition wsdl11Definition = new SimpleWsdl11Definition();
        wsdl11Definition.setWsdl(new ClassPathResource("schema/wsdl/MeFTransmitterServicesMTOM.wsdl"));
        return wsdl11Definition;
    }


}