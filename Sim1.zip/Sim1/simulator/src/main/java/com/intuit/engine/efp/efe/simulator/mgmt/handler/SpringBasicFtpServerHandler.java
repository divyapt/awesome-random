package com.intuit.engine.efp.efe.simulator.mgmt.handler;

import com.intuit.engine.efp.efe.common.EfeRuntimeException;
import com.intuit.engine.efp.efe.common.FileUtils;
import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.properties.FtpProperties;
import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import com.intuit.engine.efp.efe.util.FtpServerUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.File;
import java.io.IOException;

public class SpringBasicFtpServerHandler extends EmbeddedBasicFtpServerHandler {

    private static final Log

            logger = LogFactory.getLog(SpringBasicFtpServerHandler.class);

    public SpringBasicFtpServerHandler() {
        super();
    }


    public SpringBasicFtpServerHandler(SimHandler handler, FtpProperties ftpProperties) {
        super(handler);
        startFTPServer(ftpProperties);
    }


    @Override
    public synchronized void startServer() {
         // Decoupled startServer() method implementation into startFtpServer() to capture the sbbtFtpProperties from sbbtSimulator
    }

    /**
     * Starts the singleton ftp server
     */
    public synchronized void startFTPServer(FtpProperties ftpProperties) {
        if (ftpServer == null) {
            homeDir = new File(System.getProperty("java.io.tmpdir") + "/ftp");
            if ( logger.isInfoEnabled() ) {  // (don't access the file system unnecessarily)
                logger.info("FTP root dir = '" + homeDir.getAbsolutePath() + (homeDir.exists() ? "' exists" : "' non-existent"));
            }
            // Move the cert to the home dir
            File keystoreFile = new File(homeDir, ".keystore");
            byte[] keystore = null;
            try {
                keystore = FileUtils.readBytes(EmbeddedFtpServerHandler.class.getClassLoader().getResourceAsStream(".keystore"));
                FileUtils.writeBytes(keystoreFile.getAbsolutePath(), keystore);
                logger.info("Wrote keystore '" + keystoreFile.getAbsolutePath() + "' (" + keystore.length + " bytes)");
            } catch (IOException ex) {
                logger.error("Error preparing keystore for Embedded Basic FTP Server: '" + keystoreFile.getAbsolutePath() + "' ("
                        + (keystore==null ? "resource not read" : (keystore.length + " bytes read from resource")) + ").", ex);
            }

            // Start the ftp server
            try {
                ftpServer = FtpServerUtil.createFtpServer(ftpProperties.getPort(), ftpProperties.getUsername(), ftpProperties.getPassword(), homeDir.getAbsolutePath());
                ftpServer.start();
                logger.info("Embedded Basic FTP Server Started: localhost: " + ftpProperties.getPort());
            } catch(Exception ex) {
                logger.info("Couldn't start Embedded Basic FTP Server.  Port " + ftpProperties.getPort() + " may already be bound.  "
                        + "If so, this is probably due to another instance running, and therefore harmless"
                        + " -- check the exception here and look for 'Embedded Basic FTP Server Started' earlier.", ex);
            }
        } else {
            logger.info("Embedded Basic FTP Server already started on port: " + ftpProperties.getPort());
        }
    }

    /**
     * Loads the FTP specific properties from the web.xml file.
     */
    public void init(SiteProperties ftpConfig, Simulator mgmt) {
        File homeDir = getFtpRoot();
        if ( logger.isInfoEnabled() ) {  // (don't access the file system unnecessarily)
            logger.info("FTP root dir = '" + homeDir.getAbsolutePath() + (homeDir.exists() ? "' exists" : "' non-existent"));
        }
        if (ftpConfig.getUploadDirectory() != null)
            this.dloadDir = new File(homeDir, ftpConfig.getUploadDirectory());
        if (ftpConfig.getDownloadDirectory() != null)
            this.uploadDir = new File(homeDir, ftpConfig.getDownloadDirectory());

        // Display critical info on the management web page
        mgmt.setServerStatus("FTP Host", "localhost");
        mgmt.setServerStatus("FTP Port", "" + port);
        mgmt.setServerStatus("FTP User", DEFAULT_USER);
        mgmt.setServerStatus("FTP Download Directory", ftpConfig.getUploadDirectory());
        mgmt.setServerStatus("FTP Upload Directory", ftpConfig.getDownloadDirectory());

        // Start the ftp server
        try {
            if (getDloadDir() != null && getUploadDir() != null) {
                logger.info("init(): DloadDir='" + getDloadDir() + "', UploadDir='" + getUploadDir() + "'.");
                getDloadDir().mkdirs();
                org.apache.commons.io.FileUtils.cleanDirectory(getDloadDir());
                getUploadDir().mkdirs();
                org.apache.commons.io.FileUtils.cleanDirectory(getUploadDir());
                for (String subDir : subdirs) {
                    File upload = new File(getUploadDir(), subDir);
                    upload.mkdirs();
                    File download = new File(getDloadDir(), subDir);
                    download.mkdirs();
                }
            } else {
                logger.warn("Skipping creating default upload and download directories because they were not specified in web.xml");
            }

        } catch(Exception ex) {
            logger.error(ex);
            throw new EfeRuntimeException("Failed to start embedded FTP server", ex);
        }

        // init the child handler
        initChildren(ftpConfig, mgmt);
    }

    public void initChildren(SiteProperties config, Simulator mgmt) {
        if (childHandler != null && childHandler instanceof SpringSimHandler) {
            ((SpringSimHandler) childHandler).init(config, mgmt);
        }
    }
}
