package com.intuit.engine.efp.efe.simulator.properties.california.mef;

import com.intuit.engine.efp.efe.simulator.properties.FtpProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value={"classpath:simulator.properties" })
public class CaMefApdFtpProperties implements FtpProperties {

    @Value("${simulator.ca.mef.apd.ftp.username}")
    protected String username;
    public String getUsername() { return username; }
    public void setUsername(String inUsername) { this.username = inUsername; }

    @Value("${simulator.ca.mef.apd.ftp.password}")
    protected String password;
    public String getPassword() { return password; }
    public void setPassword(String inPassword) { this.password = inPassword; }

    @Value("${simulator.ca.mef.apd.ftp.port}")
    protected Integer port;
    public Integer getPort() { return port; }
    public void setPort(Integer inPort) { this.port = inPort; }

    @Value("${simulator.ca.mef.apd.ftp.host}")
    protected String host;
    public String getHost() { return host; }
    public void setHost(String inHost) { this.host = inHost; }

}