package com.intuit.engine.efp.efe.simulator.mgmt.handler;

import com.intuit.engine.efp.efe.mpc.persistence.config.Attribute;
import com.intuit.engine.efp.efe.mpc.persistence.config.AttributeGroup;
import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.properties.FtpProperties;
import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import com.intuit.engine.efp.efe.util.Util;

/**
 * Spring ftpHandler which reads Ftp properties (host/port/uname/pwd/upload dir/dload dir etc.)
 * from simulator properties instead of servletConfig
 */
public class SpringFtpHandler extends FtpHandler{

    private FtpProperties ftpProperties;

    public SpringFtpHandler() {
        super();
    }

    public SpringFtpHandler(SimHandler handler, FtpProperties ftpProperties) {
        super(handler);
        this.ftpProperties=ftpProperties;
    }

    /**
     * Loads the FTP specific properties from the properties.
     */
    public void init(SiteProperties siteProperties, Simulator mgmt) {
        String ftp = ftpProperties.getHost();
        String user = ftpProperties.getUsername();
        String password = ftpProperties.getPassword();
        dloadDir = siteProperties.getUploadDirectory();
        String upload = siteProperties.getDownloadDirectory();
        ftpAttrs = new AttributeGroup("ftp");
        url = Util.getURL("ftp://" + ftp);

        ftpAttrs.add(new Attribute("url", url.toExternalForm()));
        ftpAttrs.add(new Attribute("userName", user));
        ftpAttrs.add(new Attribute("userPassword", password));
        ftpAttrs.add(new Attribute("downloadDir", dloadDir));
        ftpAttrs.add(new Attribute("uploadDir", upload));

        mgmt.setServerStatus("FTP URL", url.getHost());
        mgmt.setServerStatus("FTP Port", "" + url.getPort());
        mgmt.setServerStatus("FTP User", user);
        mgmt.setServerStatus("FTP Download Directory", dloadDir);
        mgmt.setServerStatus("FTP Upload Directory", upload);

        initChildren(siteProperties, mgmt);
    }

    public void initChildren(SiteProperties config, Simulator mgmt) {
        if (childHandler != null && childHandler instanceof SpringSimHandler) {
            ((SpringSimHandler) childHandler).init(config, mgmt);
        }
    }

}
