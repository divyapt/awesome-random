package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Random;
import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class AgencyTimingEmulator {
    private Log log = LogFactory.getLog(getClass());
    private static final String MIN_DELAY_PARAM = "mindelay";
    private static final String MAX_DELAY_PARAM = "maxdelay";
    private static final String DELAY_PARAMS_FILE = "com/intuit/engine/efp/efe/simulator/irs/bit/mef/delay_params.properties";
    protected int minDelay = -1;
    protected int maxDelay = -1;
    private int delay = -1;

    public AgencyTimingEmulator(Log log) {
        this.log = log;
        log.debug("AgencyTimingEmulator constructor called.");
    }

    public void processDelayRequest(WebServiceContext wsContext) throws InterruptedException {
        if (wsContext != null) {
            MessageContext mc = wsContext.getMessageContext();
            if (mc != null) {
                HttpServletRequest req = (HttpServletRequest)mc.get("javax.xml.ws.servlet.request");
                this.processDelayRequest(req);
            } else {
                this.processDelayRequestFromFile();
            }
        } else {
            this.processDelayRequestFromFile();
        }

    }

    public void processDelayRequest(HttpServletRequest req) throws InterruptedException {
        if (req != null) {
            String minDelayParam = req.getParameter("mindelay");
            String maxDelayParam = req.getParameter("maxdelay");
            if (minDelayParam == null && maxDelayParam == null) {
                this.processDelayRequestFromFile();
            } else {
                this.processDelayRequest(minDelayParam, maxDelayParam);
            }
        } else {
            this.processDelayRequestFromFile();
        }

    }

    private void processDelayRequestFromFile() {
        InputStream delayParamsInputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("com/intuit/engine/efp/efe/simulator/irs/bit/mef/delay_params.properties");
        if (delayParamsInputStream != null) {
            this.log.info("Found delay parameters file.");
            Properties delayProps = new Properties();

            try {
                delayProps.load(delayParamsInputStream);
            } catch (IOException var5) {
                this.log.error("Error loading delay parameters file.");
                return;
            }

            String minDelayParam = delayProps.getProperty("mindelay");
            String maxDelayParam = delayProps.getProperty("maxdelay");
            this.processDelayRequest(minDelayParam, maxDelayParam);
        } else {
            this.log.info("Did not find delay parameters file.");
        }

    }

    protected void processDelayRequest(String minDelayParam, String maxDelayParam) throws IllegalArgumentException {
        boolean delayRequested = false;
        if (minDelayParam != null || maxDelayParam != null) {
            delayRequested = true;
        }

        if (delayRequested) {
            if (minDelayParam != null && minDelayParam.length() != 0) {
                if (maxDelayParam != null && maxDelayParam.length() != 0) {
                    this.log.info("AgencyTimingEmulator: Delay Parameters: minDelay: " + minDelayParam + ", maxDelay: " + maxDelayParam);
                    this.minDelay = Integer.parseInt(minDelayParam);
                    this.maxDelay = Integer.parseInt(maxDelayParam);
                    if (this.minDelay == this.maxDelay) {
                        this.delay = this.minDelay;
                    } else {
                        if (this.maxDelay <= this.minDelay) {
                            this.log.error("AgencyTimingEmulator: Max Delay (" + this.maxDelay + " must be > Min Delay (" + this.minDelay + ")");
                            throw new IllegalArgumentException("Max Delay (" + this.maxDelay + " must be > Min Delay (" + this.minDelay + ")");
                        }

                        Random random = new Random();
                        long range = (long)this.maxDelay - (long)this.minDelay + 1L;
                        long fraction = (long)((double)range * random.nextDouble());
                        this.delay = (int)(fraction + (long)this.minDelay);
                    }

                    this.log.info("AgencyTimingEmulator: Begin Agency Processing Delay (" + this.delay + " seconds)");
                    this.sleep(1000 * this.delay);
                    this.log.info("AgencyTimingEmulator: End Agency Processing Delay");
                } else {
                    this.log.error("AgencyTimingEmulator: Maximum delay not specified");
                    throw new IllegalArgumentException("Maximum delay not specified");
                }
            } else {
                this.log.error("AgencyTimingEmulator: Minimum delay not specified");
                throw new IllegalArgumentException("Minimum delay not specified");
            }
        }
    }

    protected void sleep(int delay) {
        try {
            Thread.sleep((long)delay);
        } catch (InterruptedException var3) {
        }

    }

    protected int getMinDelay() {
        return this.minDelay;
    }

    protected int getMaxDelay() {
        return this.maxDelay;
    }

    protected int getDelay() {
        return this.delay;
    }
}
