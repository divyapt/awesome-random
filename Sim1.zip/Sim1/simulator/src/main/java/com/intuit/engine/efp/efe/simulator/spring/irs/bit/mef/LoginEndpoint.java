package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.ws.Holder;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.ErrorExceptionDetail;
import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.LoginRequestType;
import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.LoginResponseType;
import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.MeFHeaderType;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.LoginService;

@Endpoint
public class LoginEndpoint {

    private static final String NAMESPACE_URI = "http://www.irs.gov/a2a/mef/MeFMSIServices.xsd";

    private static final String MEFHEADER_NAME = "{http://www.irs.gov/a2a/mef/MeFHeader.xsd}MeFHeader";

    private final LoginService loginService;

    public LoginEndpoint(LoginService loginService) {
        this.loginService = loginService;
    }

    /**
     * @see LoginService#login(Holder, LoginRequestType)
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "LoginRequest")
    @ResponsePayload
    public JAXBElement<LoginResponseType> login(@SoapHeader(MEFHEADER_NAME) MeFHeaderType meFHeader, @RequestPayload LoginRequestType login) throws ErrorExceptionDetail {
        LoginResponseType response = loginService.login(new Holder<>(meFHeader), login);
        return new JAXBElement<>(new QName(NAMESPACE_URI, "LoginResponse"), LoginResponseType.class, response);
    }

}
