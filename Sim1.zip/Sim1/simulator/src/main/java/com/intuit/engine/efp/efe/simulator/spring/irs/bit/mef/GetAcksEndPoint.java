package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;


import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.*;
import com.intuit.engine.efp.efe.common.IOUtils;
import com.intuit.engine.efp.efe.simulator.SimUtils;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBElement;
import java.math.BigInteger;
import java.util.List;

@Endpoint
public class GetAcksEndPoint {

    private static final String TRANSMITTER_NAMESPACE = "http://www.irs.gov/a2a/mef/MeFTransmitterServiceMTOM.xsd";
    private static final String MEFHEADER_NAME = "{http://www.irs.gov/a2a/mef/MeFHeader.xsd}MeFHeader";
    private Log log = LogFactory.getLog(getClass());


    @PayloadRoot(namespace = TRANSMITTER_NAMESPACE, localPart = "GetAcksRequest")
    @ResponsePayload
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT)
    public JAXBElement<GetAcksResponseType> getAcks(@RequestPayload GetAcksRequestType getAcksRequest,@SoapHeader(MEFHEADER_NAME) MeFHeaderType meFHeader) throws ErrorExceptionDetail {
        {

            log.debug("MEF simulator: sendSubmissions called.");

            String etinOfSender = meFHeader.getETIN();

            SimUtils.soapFaultRequestCheck("GetAcksService.getAcks", meFHeader.getETIN(), SimUtils.GET_ACKS_SOAP_FAULT_ETIN);

            try {
                RequestAttributes attribs = RequestContextHolder.getRequestAttributes();
                HttpServletRequest request = ((ServletRequestAttributes) attribs).getRequest();
                AgencyTimingEmulator agencyTimingEmulator = new AgencyTimingEmulator(log);
                agencyTimingEmulator.processDelayRequest(request);

                // validate the Transmission Header (soap header)
                TransmissionHeaderValidator headerValidator = new TransmissionHeaderValidator(meFHeader);
                headerValidator.validate(TransmissionHeaderValidator.Action.GET_ACKS);

                List<String> submissionIds = getAcksRequest.getSubmissionIdList().getSubmissionId();
                AcknowledgementCache acksList = AcknowledgementCache.getInstance();
                AcknowledgementCache.GetAcksResult acksResult = acksList.getAcks(submissionIds, etinOfSender);

                // generate the zip file attachment containing the acks
                GetAcksResponseZipFile responseZipFile = new GetAcksResponseZipFile(acksResult.acks);
                byte[] responseData = responseZipFile.getRawBytes();
                Base64Binary response = new Base64Binary();
                response.setValue(responseData);

                // Missing acks
                GetAcksResponseType gart = new GetAcksResponseType();
                SubmissionErrorListType errorList = new SubmissionErrorListType();
                List<String> missingAcks = acksResult.missingAcks;
                errorList.setCnt(BigInteger.valueOf(missingAcks.size()));
                missingAcks.forEach(missingAck -> new SubmissionErrorType().setSubmissionId(missingAck));
                gart.setSubmissionErrorList(errorList);
                gart.setAcknowledgementListAttMTOM(response);

                TransmissionHeaderValidator.addFakeNotificationMessageToHeader(meFHeader);

                ObjectFactory factory = new ObjectFactory();
                JAXBElement<GetAcksResponseType> jaxbElement = factory.createGetAcksResponse(gart);

                return jaxbElement;
            } catch (RuntimeException e) {
                // Probably a parsing error - possibly legitimate test case
                log.error("Error during getting new acks", e);
                throw toMeFException(e);
            } catch (Exception e) {
                // unexpected error - could be bug in simulator
                log.error("Unexepected Error during get acks operation", e);
                throw toMeFException(e);
            }
        }

    }

    private ErrorExceptionDetail toMeFException(Exception ex) {
        ErrorExceptionDetailType faultInfo = new ErrorExceptionDetailType();
        faultInfo.setErrorMessageCd(ex.getMessage());  //.setErrorCode(ex.getMessage());
        faultInfo.setErrorMessageTxt(new String(IOUtils.toByteArray(ex)));  //.setErrorMessage(new String(IOUtils.toByteArray(ex)));
        return new ErrorExceptionDetail("Problem during SendSubmissions", faultInfo, ex);
    }


}
