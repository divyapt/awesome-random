package com.intuit.engine.efp.efe.simulator.properties.fsb;

import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value={"classpath:simulator.properties" })
public class FsbSiteProperties implements SiteProperties {

    @Value("${simulator.fsb.iit.pro.ftp.upload.dir}")
    protected String uploadDirectory;
    public String getUploadDirectory() { return uploadDirectory; }
    public void setUploadDirectory(String inUploadDirectory) { this.uploadDirectory = inUploadDirectory; }

    @Value("${simulator.fsb.iit.pro.ftp.download.dir}")
    protected String downloadDirectory;
    public String getDownloadDirectory() { return downloadDirectory; }
    public void setDownloadDirectory(String inDownloadDirectory) { this.downloadDirectory = inDownloadDirectory; }

    @Value("${simulator.fsb.iit.pro.ftp.process.dir}")
    protected String processDirectory;
    public String getProcessDirectory() { return processDirectory; }
    public void setProcessDirectory(String inProcessDirectory) { this.processDirectory = inProcessDirectory; }

    @Value("${simulator.fsb.iit.pro.ftp.acks.dir}")
    protected String acksDirectory;
    public String getAcksDirectory() { return acksDirectory; }
    public void setAcksDirectory(String inAcksDirectory) { this.acksDirectory = inAcksDirectory; }

    @Value("${simulator.fsb.iit.pro.ftp.archive.dir}")
    protected String archiveDirectory;
    public String getArchiveDirectory() { return archiveDirectory; }
    public void setArchiveDirectory(String inArchiveDirectory) { this.archiveDirectory = inArchiveDirectory; }

    @Value("${simulator.fsb.iit.pro.ftp.taxret.dir}")
    protected String taxRetDirectory;
    public String getTaxRetDirectory() { return taxRetDirectory; }

    @Value("${simulator.fsb.iit.pro.ftp.taxmef.dir}")
    protected String taxMefDirectory;
    public String getTaxMefDirectory() { return taxMefDirectory; }

    @Value("${simulator.fsb.iit.polling.freq}")
    public String pollingFrequency;
    public String getPollingFrequency() { return pollingFrequency; }

    @Value("${simulator.fsb.iit.pro.transmitterId}")
    protected String transmitterId;
    public String getTransmitterId() {
        return transmitterId;
    }

    public void setPollingFrequency(String inPollingFrequency) { this.pollingFrequency = inPollingFrequency; }

    @Override
    public String getEnrollmentDirectory() {
        return null;
    }

    @Override
    public void setEnrollmentDirectory(String inEnrollmentDirectory) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void setTransmitterId(String inTransmitterId) {
        throw new UnsupportedOperationException();
    }

}
