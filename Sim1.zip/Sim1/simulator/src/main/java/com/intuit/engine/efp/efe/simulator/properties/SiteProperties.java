package com.intuit.engine.efp.efe.simulator.properties;

/**
 * Ftp upload/download/Process/Acks directory properties.
 */
public interface SiteProperties {

    public String getUploadDirectory();
    public void setUploadDirectory(String inUploadDirectory);

    public String getDownloadDirectory();
    public void setDownloadDirectory(String inDownloadDirectory);

    public String getProcessDirectory();
    public void setProcessDirectory(String inProcessDirectory);

    public String getAcksDirectory();
    public void setAcksDirectory(String inAcksDirectory);

    public String getArchiveDirectory();
    public void setArchiveDirectory(String inArchiveDirectory);

    public String getEnrollmentDirectory();
    public void setEnrollmentDirectory(String inEnrollmentDirectory);

    public String getTransmitterId();
    public void setTransmitterId(String inTransmitterId);

    public String getPollingFrequency();
    public void setPollingFrequency(String inPollingFrequency);
}
