package com.intuit.engine.efp.efe.simulator.fsb;

import com.intuit.engine.efp.efe.common.EfeRuntimeException;
import com.intuit.engine.efp.efe.simulator.fbar.SpringFbarSimulator;
import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.*;
import com.intuit.engine.efp.efe.simulator.properties.fsb.FsbProperties;
import com.intuit.engine.efp.efe.simulator.properties.fsb.FsbSiteProperties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

/**
 * Spring hook for FSB Simulator.
 */
@Service
public class SpringFsbSimulator  extends FsbSimulator {

    private static final Log log = LogFactory.getLog(SpringFbarSimulator.class);

    @Autowired
    FsbProperties fsbProperties;

    public SpringFsbSimulator() {

    }

    public SpringFsbSimulator(Simulator mgmt)
    {
        addManagement(mgmt);
    }

    public void addManagement(Simulator mgmt) {

        management = mgmt;
        handlerPro = new SpringBasicFtpServerHandler(new SpringDaemonHandler(this), fsbProperties.fsbFtpPropertes);
        handlerPro.setAppendMode(true);    // FSB must append to existing records if they have not already been picked up
        handlerPro.setFtpFilter(new ExtensionFtpFilter(".000.zip"));
        handlerPro.setLog(log);

        handlerProMeF = new SpringBasicFtpServerHandler(new SpringDaemonHandler(this), fsbProperties.fsbFtpPropertes);
        handlerPro.setAppendMode(true);    // FSB must append to existing records if they have not already been picked up
        handlerPro.setFtpFilter(new ExtensionFtpFilter(".000.zip"));
        handlerPro.setLog(log);
    }

    public void init() {

        ((SpringBasicFtpServerHandler)handlerPro).init(fsbProperties.fsbSiteProperties, management);
        ((SpringBasicFtpServerHandler)handlerProMeF).init(fsbProperties.fsbSiteProperties, management);
        try {
            createFtpDirectories(handlerPro, fsbProperties.fsbSiteProperties);
            handlerPro.setDloadDir(fsbProperties.fsbSiteProperties.getTaxRetDirectory());
            handlerPro.setUploadDir(fsbProperties.fsbSiteProperties.getAcksDirectory());

            createFtpDirectories(handlerProMeF, fsbProperties.fsbSiteProperties);
            handlerProMeF.setDloadDir(fsbProperties.fsbSiteProperties.getTaxMefDirectory());
            handlerProMeF.setUploadDir(fsbProperties.fsbSiteProperties.getAcksDirectory());

            proTransmitterId = fsbProperties.fsbSiteProperties.getTransmitterId();
        } catch (Exception ex) {
            log.error(ex);
            throw new EfeRuntimeException("Failed to create FTP directories for Fbar Simulator", ex);
        }
    }
    /**
     * Create the upload, Download, Process, Acks, Archive, Enrollment directories for each Handler.
     * @param handler
     */
    private void createFtpDirectories(EmbeddedFtpServerHandler handler, FsbSiteProperties ftpConfig) throws IOException {
        handler.createDir(ftpConfig.getUploadDirectory());
        handler.createDir(ftpConfig.getDownloadDirectory());
        handler.createDir(ftpConfig.getProcessDirectory());
        handler.createDir(ftpConfig.getAcksDirectory());
        handler.createDir(ftpConfig.getArchiveDirectory());
        handler.createDir(ftpConfig.getTaxRetDirectory());
        handler.createDir(ftpConfig.getTaxMefDirectory());
    }
}
