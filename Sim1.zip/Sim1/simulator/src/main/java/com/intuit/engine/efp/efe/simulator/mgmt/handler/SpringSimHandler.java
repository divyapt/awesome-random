package com.intuit.engine.efp.efe.simulator.mgmt.handler;

import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;

public interface SpringSimHandler {

    public void init(SiteProperties config, Simulator mgmt);
}
