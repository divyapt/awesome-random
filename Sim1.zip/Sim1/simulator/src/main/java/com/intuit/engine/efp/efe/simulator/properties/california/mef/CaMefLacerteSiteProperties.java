package com.intuit.engine.efp.efe.simulator.properties.california.mef;

import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value={"classpath:simulator.properties" })
public class CaMefLacerteSiteProperties implements SiteProperties {

    @Value("${simulator.ca.mef.lacerte.ftp.upload.dir}")
    protected String uploadDirectory;
    public String getUploadDirectory() { return uploadDirectory; }
    public void setUploadDirectory(String inUploadDirectory) { this.uploadDirectory = inUploadDirectory; }

    @Value("${simulator.ca.mef.lacerte.ftp.download.dir}")
    protected String downloadDirectory;
    public String getDownloadDirectory() { return downloadDirectory; }
    public void setDownloadDirectory(String inDownloadDirectory) { this.downloadDirectory = inDownloadDirectory; }

    @Override
    public String getPollingFrequency() {
        return null;
    }

    @Override
    public void setPollingFrequency(String inPollingFrequency) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String getProcessDirectory() {
        return null;
    }

    @Override
    public void setProcessDirectory(String inProcessDirectory) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String getAcksDirectory() {
        return null;
    }

    @Override
    public void setAcksDirectory(String inAcksDirectory) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String getArchiveDirectory() {
        return null;
    }

    @Override
    public void setArchiveDirectory(String inArchiveDirectory) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String getEnrollmentDirectory() {
        return null;
    }

    @Override
    public void setEnrollmentDirectory(String inEnrollmentDirectory) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String getTransmitterId() {
        return null;
    }

    @Override
    public void setTransmitterId(String inTransmitterId) {
        throw new UnsupportedOperationException();
    }

}
