package com.intuit.engine.efp.efe.simulator.properties.sbbt;

import com.intuit.engine.efp.efe.simulator.properties.FtpProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
//@ConfigurationProperties(prefix = "simulator.sbbt.iit.ftp")
@PropertySource(value={"classpath:simulator.properties" })
public class SbbtFtpProperties implements FtpProperties {
    @Value("${simulator.sbbt.iit.ftp.username}")
    protected String username;
    public String getUsername() { return username; }
    public void setUsername(String inUsername) { this.username = inUsername; }

    @Value("${simulator.sbbt.iit.ftp.password}")
    protected String password;
    public String getPassword() { return password; }
    public void setPassword(String inPassword) { this.password = inPassword; }

    @Value("${simulator.sbbt.iit.ftp.port}")
    protected Integer port;
    public Integer getPort() { return port; }
    public void setPort(Integer inPort) { this.port = inPort; }

    @Value("${simulator.sbbt.iit.ftp.host}")
    protected String host;
    public String getHost() { return host; }
    public void setHost(String inHost) { this.host = inHost; }
}
