package com.intuit.engine.efp.efe.simulator.configuration;

import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Configuration;

@Configuration
@ImportResource({"classpath*:application-context.xml"})
public class XmlConfiguration {
}
