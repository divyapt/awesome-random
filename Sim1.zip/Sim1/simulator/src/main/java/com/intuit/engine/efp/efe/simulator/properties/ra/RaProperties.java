package com.intuit.engine.efp.efe.simulator.properties.ra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value={"classpath:simulator.properties" })
public class RaProperties {

    @Autowired
    public RaFtpProperties raFtpProperties;


    @Autowired
    public RaSiteProperties raSiteProperties;
}
