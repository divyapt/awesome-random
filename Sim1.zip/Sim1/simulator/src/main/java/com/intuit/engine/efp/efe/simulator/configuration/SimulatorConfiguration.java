package com.intuit.engine.efp.efe.simulator.configuration;

import com.intuit.engine.efp.efe.simulator.california.mef.CaMefServlet;
import com.intuit.engine.efp.efe.simulator.california.mef.SpringCaMefSimulator;
import com.intuit.engine.efp.efe.simulator.california.mef.bit.CaMefBitServlet;
import com.intuit.engine.efp.efe.simulator.california.mef.bit.SpringCaMefBitSimulator;
import com.intuit.engine.efp.efe.simulator.fbar.FbarServlet;
import com.intuit.engine.efp.efe.simulator.fbar.SpringFbarSimulator;
import com.intuit.engine.efp.efe.simulator.fsb.FsbServlet;
import com.intuit.engine.efp.efe.simulator.fsb.SpringFsbSimulator;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.LoginService;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.LogoutService;
import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.properties.Properties;
import com.intuit.engine.efp.efe.simulator.ra.SpringRaSimulator;
import com.intuit.engine.efp.efe.simulator.ra.iit.RaServlet;
import com.intuit.engine.efp.efe.simulator.rc.SpringRcSimulator;
import com.intuit.engine.efp.efe.simulator.rc.iit.RcServlet;
import com.intuit.engine.efp.efe.simulator.sbbt.SbbtServlet;
import com.intuit.engine.efp.efe.simulator.sbbt.SpringSbbtSimulator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
public class SimulatorConfiguration {

    @Autowired
    public Properties simulatorProperties;

    @Bean
    public Simulator getSbbtSimulator(SpringSbbtSimulator sbbtSimulator) {
        Simulator mgmt = new SbbtServlet(sbbtSimulator);
        sbbtSimulator.addManagement(mgmt);
        sbbtSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getRcSimulator(SpringRcSimulator rcSimulator) {
        Simulator mgmt = new RcServlet(rcSimulator);
        rcSimulator.addManagement(mgmt);
        rcSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getRaSimulator(SpringRaSimulator raSimulator) {
        Simulator mgmt = new RaServlet(raSimulator);
        raSimulator.addManagement(mgmt);
        raSimulator.init();
        return mgmt;
    }

    //Initialize FBAR Simulator beans
    @Bean
    public Simulator getFbarApdSimulator() {
        SpringFbarSimulator fbarApdSimulator = new SpringFbarSimulator();
        Simulator mgmt = new FbarServlet(fbarApdSimulator);
        fbarApdSimulator.setFbarProperties(simulatorProperties.fbarApdProperties);
        fbarApdSimulator.addManagement(mgmt);
        fbarApdSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getFbarLacerteSimulator() {
        SpringFbarSimulator fbarLacerteSimulator = new SpringFbarSimulator();
        Simulator mgmt = new FbarServlet(fbarLacerteSimulator);
        fbarLacerteSimulator.setFbarProperties(simulatorProperties.fbarLacerteProperties);
        fbarLacerteSimulator.addManagement(mgmt);
        fbarLacerteSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getFbarProSimulator() {
        SpringFbarSimulator fbarProSimulator = new SpringFbarSimulator();
        Simulator mgmt = new FbarServlet(fbarProSimulator);
        fbarProSimulator.setFbarProperties(simulatorProperties.fbarProProperties);
        fbarProSimulator.addManagement(mgmt);
        fbarProSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getFbarXmlApdSimulator() {
        SpringFbarSimulator fbarXmlApdSimulator = new SpringFbarSimulator();
        Simulator mgmt = new FbarServlet(fbarXmlApdSimulator);
        fbarXmlApdSimulator.setFbarProperties(simulatorProperties.fbarXmlApdProperties);
        fbarXmlApdSimulator.addManagement(mgmt);
        fbarXmlApdSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getFbarXmlLacerteSimulator() {
        SpringFbarSimulator fbarXmlLacerteSimulator = new SpringFbarSimulator();
        Simulator mgmt = new FbarServlet(fbarXmlLacerteSimulator);
        fbarXmlLacerteSimulator.setFbarProperties(simulatorProperties.fbarXmlLacerteProperties);
        fbarXmlLacerteSimulator.addManagement(mgmt);
        fbarXmlLacerteSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getFbarXmlProSimulator() {
        SpringFbarSimulator fbarXmlProSimulator = new SpringFbarSimulator();
        Simulator mgmt = new FbarServlet(fbarXmlProSimulator);
        fbarXmlProSimulator.setFbarProperties(simulatorProperties.fbarXmlProProperties);
        fbarXmlProSimulator.addManagement(mgmt);
        fbarXmlProSimulator.init();
        return mgmt;
    }

    //Initialize CA MEF Simulator beans
    @Bean
    public Simulator getCaMefApdSimulator() {
        SpringCaMefSimulator caMefApdSimulator = new SpringCaMefSimulator();
        Simulator mgmt = new CaMefServlet(caMefApdSimulator);
        caMefApdSimulator.setMefBitProperties(simulatorProperties.caMefApdProperties);
        caMefApdSimulator.addManagement(mgmt);
        caMefApdSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getCaMefProSimulator() {
        SpringCaMefSimulator caMefProSimulator = new SpringCaMefSimulator();
        Simulator mgmt = new CaMefServlet(caMefProSimulator);
        caMefProSimulator.setMefBitProperties(simulatorProperties.caMefProProperties);
        caMefProSimulator.addManagement(mgmt);
        caMefProSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getCaMefLacerteSimulator() {
        SpringCaMefSimulator caMefLacerteSimulator = new SpringCaMefSimulator();
        Simulator mgmt = new CaMefServlet(caMefLacerteSimulator);
        caMefLacerteSimulator.setMefBitProperties(simulatorProperties.caMefLacerteProperties);
        caMefLacerteSimulator.addManagement(mgmt);
        caMefLacerteSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getCaMefSimulator() {
        SpringCaMefSimulator caMefSimulator = new SpringCaMefSimulator();
        Simulator mgmt = new CaMefServlet(caMefSimulator);
        caMefSimulator.setMefBitProperties(simulatorProperties.caMefProperties);
        caMefSimulator.addManagement(mgmt);
        caMefSimulator.init();
        return mgmt;
    }

    //Initialize CA MEF BIT Simulator beans
    @Bean
    public Simulator getCaMefBitApdSimulator() {
        SpringCaMefBitSimulator caMefBitApdSimulator = new SpringCaMefBitSimulator();
        Simulator mgmt = new CaMefBitServlet(caMefBitApdSimulator);
        caMefBitApdSimulator.setMefBitProperties(simulatorProperties.caMefBitApdProperties);
        caMefBitApdSimulator.addManagement(mgmt);
        caMefBitApdSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getCaMefBitLacerteSimulator() {
        SpringCaMefBitSimulator caMefBitLacerteSimulator = new SpringCaMefBitSimulator();
        Simulator mgmt = new CaMefBitServlet(caMefBitLacerteSimulator);
        caMefBitLacerteSimulator.setMefBitProperties(simulatorProperties.caMefBitLacerteProperties);
        caMefBitLacerteSimulator.addManagement(mgmt);
        caMefBitLacerteSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getCaMefBitProSimulator() {
        SpringCaMefBitSimulator caMefBitProSimulator = new SpringCaMefBitSimulator();
        Simulator mgmt = new CaMefBitServlet(caMefBitProSimulator);
        caMefBitProSimulator.setMefBitProperties(simulatorProperties.caMefBitProProperties);
        caMefBitProSimulator.addManagement(mgmt);
        caMefBitProSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getCaMefBitSimulator() {
        SpringCaMefBitSimulator caMefBitSimulator = new SpringCaMefBitSimulator();
        Simulator mgmt = new CaMefBitServlet(caMefBitSimulator);
        caMefBitSimulator.setMefBitProperties(simulatorProperties.caMefBitProperties);
        caMefBitSimulator.addManagement(mgmt);
        caMefBitSimulator.init();
        return mgmt;
    }

    @Bean
    public Simulator getFsbSimulator(SpringFsbSimulator fsbSimulator) {
        Simulator mgmt = new FsbServlet(fsbSimulator);
        fsbSimulator.addManagement(mgmt);
        fsbSimulator.init();
        return mgmt;
    }

    @Bean
    public LogoutService getLogoutService() {
        return new LogoutService();
    }

    @Bean
    public LoginService getLoginService() {
        return new LoginService();
    }

}



