package com.intuit.engine.efp.efe.simulator.california.mef;

import com.intuit.engine.efp.efe.common.EfeRuntimeException;
import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.SpringDaemonHandler;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.SpringFtpHandler;
import com.intuit.engine.efp.efe.simulator.properties.CommonProperties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Spring hook for CA MEF Simulator.
 */
public class SpringCaMefSimulator extends CaMefSimulator {

    private static final Log log = LogFactory.getLog(com.intuit.engine.efp.efe.simulator.california.mef.SpringCaMefSimulator.class);

    private CommonProperties mefProperties;

    public SpringCaMefSimulator() {

    }

    public SpringCaMefSimulator(Simulator mgmt)
    {
        addManagement(mgmt);
    }

    public void addManagement(Simulator mgmt) {

        management = mgmt;
        handler = new SpringFtpHandler(new SpringDaemonHandler(this), mefProperties.getFtpProperties());
        handler.setLog(log);
    }

    public void init() {

        ((SpringFtpHandler)handler).init(mefProperties.getSiteProperties(), management);
        try {
            ((SpringFtpHandler)handler).createDir(mefProperties.getSiteProperties().getUploadDirectory());
            ((SpringFtpHandler)handler).createDir(mefProperties.getSiteProperties().getDownloadDirectory());
        } catch (Exception ex) {
            log.error(ex);
            throw new EfeRuntimeException("Failed to create FTP directories for CA MEF Simulator", ex);
        }
    }

    public void setMefBitProperties(CommonProperties mefProperties) {
        this.mefProperties = mefProperties;
    }
}