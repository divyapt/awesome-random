package com.intuit.engine.efp.efe.simulator.fbar;

import com.intuit.engine.efp.efe.common.EfeRuntimeException;
import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.SpringDaemonHandler;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.SpringFtpHandler;
import com.intuit.engine.efp.efe.simulator.properties.CommonProperties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Spring hook for FBAR Simulator.
 */
public class SpringFbarSimulator extends FbarSimulator {

    private static final Log log = LogFactory.getLog(SpringFbarSimulator.class);

    private CommonProperties fbarProperties;

    public SpringFbarSimulator() {

    }

    public SpringFbarSimulator(Simulator mgmt)
    {
        addManagement(mgmt);
    }

    public void addManagement(Simulator mgmt) {

        management = mgmt;
        handler = new SpringFtpHandler(new SpringDaemonHandler(this), fbarProperties.getFtpProperties());
        handler.setLog(log);
    }

    public void init() {

        ((SpringFtpHandler)handler).init(fbarProperties.getSiteProperties(), management);
        try {
            handler.createDir(fbarProperties.getSiteProperties().getUploadDirectory());
            handler.createDir(fbarProperties.getSiteProperties().getDownloadDirectory());
        } catch (Exception ex) {
            log.error(ex);
            throw new EfeRuntimeException("Failed to create FTP directories for Fbar Simulator", ex);
        }
    }
    public CommonProperties getFbarProperties() {

        return fbarProperties;
    }

    public void setFbarProperties(CommonProperties fbarProperties) {

        this.fbarProperties = fbarProperties;
    }
}
