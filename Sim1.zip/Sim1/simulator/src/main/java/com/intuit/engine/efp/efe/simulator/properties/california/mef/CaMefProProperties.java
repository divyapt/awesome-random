package com.intuit.engine.efp.efe.simulator.properties.california.mef;

import com.intuit.engine.efp.efe.simulator.properties.CommonProperties;
import com.intuit.engine.efp.efe.simulator.properties.FtpProperties;
import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value={"classpath:simulator.properties" })
public class CaMefProProperties  implements CommonProperties {

    @Autowired
    public CaMefProFtpProperties caMefProFtpProperties;


    @Autowired
    public CaMefProSiteProperties caMefProSiteProperties;

    @Override
    public FtpProperties getFtpProperties() {
        return caMefProFtpProperties;
    }

    @Override
    public SiteProperties getSiteProperties() {
        return caMefProSiteProperties;
    }
}
