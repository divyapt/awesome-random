package com.intuit.engine.efp.efe.simulator.ra;

import com.intuit.engine.efp.efe.simulator.mgmt.Simulator;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.SpringDaemonHandler;
import com.intuit.engine.efp.efe.simulator.mgmt.handler.SpringFtpHandler;
import com.intuit.engine.efp.efe.simulator.properties.ra.RaProperties;
import com.intuit.engine.efp.efe.simulator.ra.iit.RaSimulator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Spring hook for RA Simulator.
 */
@Service
public class SpringRaSimulator extends RaSimulator {

    private static final Log log = LogFactory.getLog(SpringRaSimulator.class);

    @Autowired
    protected RaProperties raProperties;

    public SpringRaSimulator() {

    }

    public SpringRaSimulator(Simulator mgmt)
    {
        addManagement(mgmt);
    }

   public void addManagement(Simulator mgmt) {

        management = mgmt;
        handlerPro = new SpringFtpHandler(new SpringDaemonHandler(this), raProperties.raFtpProperties);
        handlerPro.setLog(log);
    }

    public void init() {

        ((SpringFtpHandler)handlerPro).init(raProperties.raSiteProperties, management);
    }

}
