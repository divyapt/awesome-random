package com.intuit.engine.efp.efe.simulator.properties.sbbt;

import com.intuit.engine.efp.efe.simulator.properties.SiteProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
//@ConfigurationProperties(prefix = "simulator.sbbt.iit.per.site2")
@PropertySource(value={"classpath:simulator.properties" })
public class PerSite2Properties implements SiteProperties {
    @Value("${simulator.sbbt.iit.per.site2.ftp.upload.dir}")
    protected String uploadDirectory;
    public String getUploadDirectory() { return uploadDirectory; }
    public void setUploadDirectory(String inUploadDirectory) { this.uploadDirectory = inUploadDirectory; }

    @Value("${simulator.sbbt.iit.per.site2.ftp.download.dir}")
    protected String downloadDirectory;
    public String getDownloadDirectory() { return downloadDirectory; }
    public void setDownloadDirectory(String inDownloadDirectory) { this.downloadDirectory = inDownloadDirectory; }

    @Value("${simulator.sbbt.iit.per.site2.ftp.process.dir}")
    protected String processDirectory;
    public String getProcessDirectory() { return processDirectory; }
    public void setProcessDirectory(String inProcessDirectory) { this.processDirectory = inProcessDirectory; }

    @Value("${simulator.sbbt.iit.per.site2.ftp.acks.dir}")
    protected String acksDirectory;
    public String getAcksDirectory() { return acksDirectory; }
    public void setAcksDirectory(String inAcksDirectory) { this.acksDirectory = inAcksDirectory; }

    @Value("${simulator.sbbt.iit.per.site2.ftp.archive.dir}")
    protected String archiveDirectory;
    public String getArchiveDirectory() { return archiveDirectory; }
    public void setArchiveDirectory(String inArchiveDirectory) { this.archiveDirectory = inArchiveDirectory; }

    @Value("${simulator.sbbt.iit.per.site2.ftp.enrollment.dir}")
    protected String enrollmentDirectory;
    public String getEnrollmentDirectory() { return enrollmentDirectory; }
    public void setEnrollmentDirectory(String inEnrollmentDirectory) { this.enrollmentDirectory = inEnrollmentDirectory; }

    @Value("${simulator.sbbt.iit.per.site2.transmitterId}")
    protected String transmitterId;
    public String getTransmitterId() { return transmitterId; }
    public void setTransmitterId(String inTransmitterId) { this.transmitterId = inTransmitterId; }

    @Value("${simulator.sbbt.iit.per.site2.polling.freq}")
    public String pollingFrequency;
    public String getPollingFrequency() { return pollingFrequency; }
    public void setPollingFrequency(String inPollingFrequency) { this.pollingFrequency = inPollingFrequency; }
}
