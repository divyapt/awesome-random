package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;

import com.intuit.engine.efp.efe.simulator.configuration.JaxbConfiguration;
import com.intuit.engine.efp.efe.simulator.configuration.WebServiceConfig;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.LoginService;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.LogoutService;
import com.intuit.engine.efp.efe.util.MockServiceLocator;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ws.test.server.MockWebServiceClient;

import static org.springframework.ws.test.server.RequestCreators.withSoapEnvelope;
import static org.springframework.ws.test.server.ResponseMatchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {WebServiceConfig.class, JaxbConfiguration.class, LogoutEndPointTest.LogoutTestConfiguration.class})
public class LogoutEndPointTest extends TestBase {

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/LogoutRequestAndResponseXmls/LogoutRequestWithoutSecurity.xml")
    private Resource logoutRequestWithoutSecurity;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/LogoutRequestAndResponseXmls/LogoutRequestWithoutHeader.xml")
    private Resource logoutRequestWithoutHeader;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/LogoutRequestAndResponseXmls/LogoutRequestWithoutMefHeader.xml")
    private Resource logoutRequestWithoutMefHeader;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/LogoutRequestAndResponseXmls/LogoutRequestWithSecurity.xml")
    private Resource logoutRequestWithSecurity;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/LogoutRequestAndResponseXmls/LogoutResponse.xml")
    private Resource logoutResponse;

    private MockWebServiceClient mockClient;

    @TestConfiguration
    @Import(LogoutEndPoint.class)
    public static class LogoutTestConfiguration {

        @Bean
        public LoginService getLoginService() {
            return new LoginService();
        }

        @Bean
        public LogoutService getLogoutService() {
            return new LogoutService();
        }

    }
    @Before
    public void createClient() throws Exception {
        mockClient = MockWebServiceClient.createClient(applicationContext);
        MockServiceLocator.setup();
    }

    @Test
    public void test_validLogoutRequest() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(logoutRequestWithoutSecurity)).andExpect(payload(logoutResponse));
    }

    @Test
    public void test_invalidLogoutRequestWithoutHeader() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(logoutRequestWithoutHeader)).andExpect(serverOrReceiverFault());

    }

    @Test
    public void test_invalidLogoutRequestWithoutMefHeader() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(logoutRequestWithoutMefHeader)).andExpect(serverOrReceiverFault());

    }

    @Ignore("until security is working")
    @Test
    public void test_validLogoutRequestWithSecurity() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(logoutRequestWithSecurity)).andExpect(payload(logoutResponse));

    }

}
