package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;

import static org.springframework.ws.test.server.RequestCreators.withSoapEnvelope;
import static org.springframework.ws.test.server.ResponseMatchers.*;

import java.io.IOException;

import javax.xml.transform.Source;

import com.intuit.engine.efp.efe.simulator.irs.bit.mef.SendSubmissionsService;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ws.test.server.MockWebServiceClient;
import org.springframework.xml.transform.ResourceSource;

import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.LoginRequestType;
import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.MeFHeaderType;
import com.intuit.engine.efp.efe.simulator.configuration.JaxbConfiguration;
import com.intuit.engine.efp.efe.simulator.configuration.WebServiceConfig;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.LoginService;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.LogoutService;

/**
 * @see LoginEndpoint
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { WebServiceConfig.class, JaxbConfiguration.class, LoginEndpointIntegrationTest.LoginTestConfiguration.class })
public class LoginEndpointIntegrationTest {

    @TestConfiguration
    @Import(LoginEndpoint.class)
    public static class LoginTestConfiguration {

        @Bean
        public LoginService getLoginService() {
            return new LoginService();
        }

        @Bean
        public LogoutService getLogoutService() {
            return new LogoutService();
        }

    }

    @Autowired
    private ApplicationContext applicationContext;

    private MockWebServiceClient mockClient;

    @Before
    public void setUp() {
        mockClient = MockWebServiceClient.createClient(applicationContext);
    }

    private Source getSource(String filename) throws IOException {
        return new ResourceSource(new ClassPathResource(filename, LoginEndpointIntegrationTest.class));
    }

    /**
     * @see LoginEndpoint#login(MeFHeaderType, LoginRequestType)
     */
    @Test
    @Ignore("until security is working")
    public void loginWithSecurity() throws IOException {
        Source requestPayload = getSource("loginRequestWithSecurity.xml");
        mockClient
                .sendRequest(withSoapEnvelope(requestPayload))
                .andExpect(noFault());
    }

    /**
     * @see LoginEndpoint#login(MeFHeaderType, LoginRequestType)
     */
    @Test
    public void loginWithoutHeader() throws IOException {
        Source requestPayload = getSource("loginRequestWithoutHeader.xml");
        mockClient
                .sendRequest(withSoapEnvelope(requestPayload))
                .andExpect(serverOrReceiverFault()); // "No Security Header found"
    }

    /**
     * @see LoginEndpoint#login(MeFHeaderType, LoginRequestType)
     */
    @Test
    public void loginWithoutSecurity() throws IOException {
        Source requestPayload = getSource("loginRequestWithoutSecurity.xml");
        mockClient
                .sendRequest(withSoapEnvelope(requestPayload))
                .andExpect(serverOrReceiverFault()); // "No Security Header found"
    }

    /**
     * @see LoginEndpoint#login(MeFHeaderType, LoginRequestType)
     */
    @Test
    public void loginWithMeFHeader() throws IOException {
        Source requestPayload = getSource("loginRequestWithMeFHeader.xml");
        mockClient
                .sendRequest(withSoapEnvelope(requestPayload))
                .andExpect(noFault()); // "No Security Header found"
    }

    /**
     * @see LoginEndpoint#login(MeFHeaderType, LoginRequestType)
     */
    @Test
    public void loginWithoutMeFHeader() throws IOException {
        Source requestPayload = getSource("loginRequestWithoutMeFHeader.xml");
        mockClient
                .sendRequest(withSoapEnvelope(requestPayload))
                .andExpect(mustUnderstandFault());
    }

}