package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;

import com.intuit.engine.efp.efe.simulator.configuration.JaxbConfiguration;
import com.intuit.engine.efp.efe.simulator.configuration.WebServiceConfig;
import com.intuit.engine.efp.efe.util.MockServiceLocator;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ws.test.server.MockWebServiceClient;

import java.io.IOException;
import java.io.InputStream;
import static org.springframework.ws.test.server.RequestCreators.withSoapEnvelope;
import static org.springframework.ws.test.server.ResponseMatchers.*;

@RunWith(SpringRunner.class)
@Import(SubmissionsEndPoint.class)
@SpringBootTest(classes = {WebServiceConfig.class, JaxbConfiguration.class})
public class SubmissionsEndPointTest extends TestBase {

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/SendSubmissionsRequestAndResponseXmls/SendSubmissionRequest.xml")
    private Resource sendSubmissionRequest;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/SendSubmissionsRequestAndResponseXmls/SendSubmissionInvalidRequest.xml")
    private Resource sendSubmissionInvalidRequest;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/SendSubmissionsRequestAndResponseXmls/SendSubmissionInvalidWithNoElectrPostMark.xml")
    private Resource sendSubmissionInvalidWithNoElectricPostRequest;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/SendSubmissionsRequestAndResponseXmls/SendSubmissionInvalidWithNoAttchmentReq.xml")
    private Resource sendSubmissionInvalidWithNoAttachmentRequest;

    @Value(value = "classpath:SendSubRes.xml")
    private Resource sendSubmissionResponse;


    private MockWebServiceClient mockClient;


    @Before
    public void createClient() {
        mockClient = MockWebServiceClient.createClient(applicationContext);
       // MockServiceLocator.setup();
    }

    @Test
    public void test_validSendSubmission() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(sendSubmissionRequest)).andExpect(noFault());
    }


    @Test
    public void test_invalidSendSubmissionWithNoSubmissionIdInRequest() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(sendSubmissionInvalidRequest)).andExpect(serverOrReceiverFault());

    }

    @Test
    public void test_invalidSendSubmissionWithNoElectronicPostmarkTsInRequest() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(sendSubmissionInvalidWithNoElectricPostRequest)).andExpect(noFault());

    }

    @Test
    public void test_invalidSendSubmissionWithNoAttachmentRequest() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(sendSubmissionInvalidWithNoAttachmentRequest)).andExpect(serverOrReceiverFault());

    }

    private String getResponsePayloadStr(Resource payload) throws IOException {
        InputStream is = payload.getInputStream();
        @SuppressWarnings("deprecation")
        String payloadStr = IOUtils.toString(is);
        IOUtils.closeQuietly(is);
        return payloadStr;
    }
}