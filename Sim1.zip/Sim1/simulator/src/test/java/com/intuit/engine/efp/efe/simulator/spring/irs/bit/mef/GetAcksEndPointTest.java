package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;

import com.intuit.engine.efp.efe.simulator.configuration.JaxbConfiguration;
import com.intuit.engine.efp.efe.simulator.configuration.WebServiceConfig;
import com.intuit.engine.efp.efe.util.MockServiceLocator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ws.test.server.MockWebServiceClient;

import static org.springframework.ws.test.server.RequestCreators.withSoapEnvelope;
import static org.springframework.ws.test.server.ResponseMatchers.*;

@RunWith(SpringRunner.class)
@Import({SubmissionsEndPoint.class, GetAcksEndPoint.class})
@SpringBootTest(classes = {WebServiceConfig.class, JaxbConfiguration.class})
public class GetAcksEndPointTest extends TestBase {

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/GetAcksRequestAndResponseXmls/GetAcksRequest.xml")
    private Resource getAcksRequest;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/GetAcksRequestAndResponseXmls/GetAcksRequestWithNoSubmissionIdList.xml")
    private Resource getAcksRequestWithNoSubmissionIdList;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/GetAcksRequestAndResponseXmls/GetAcksRequestWithNoSubmissionIds.xml")
    private Resource getAcksRequestWithNoSubmissionIds;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/GetAcksRequestAndResponseXmls/GetAcksRequestWithoutHeader.xml")
    private Resource getAcksRequestWithoutHeader;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/GetAcksRequestAndResponseXmls/GetAcksRequestWithoutMefHeader.xml")
    private Resource getAcksRequestWithoutMefHeader;

    @Value(value = "classpath:com/intuit/engine/efp/efe/simulator/spring/irs/bit/mef/GetAcksRequestAndResponseXmls/GetAcksResponse.xml")
    private Resource getAcksRespnse;


    private MockWebServiceClient mockClient;


    @Before
    public void createClient() throws Exception {
        mockClient = MockWebServiceClient.createClient(applicationContext);
        MockServiceLocator.setup();
    }

    @Test
    public void test_validGetAcksRequest() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(getAcksRequest)).andExpect(noFault());
    }


    @Test
    public void test_invalidGetAcksWithNoSubmissionIdListInRequest() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(getAcksRequestWithNoSubmissionIdList)).andExpect(serverOrReceiverFault());

    }

    @Test
    public void test_invalidGetAcksWithNoSubmissionIdsInRequest() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(getAcksRequestWithNoSubmissionIds)).andExpect(noFault());

    }


    @Test
    public void test_invalidGetAcksRequestWithoutHeader() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(getAcksRequestWithoutHeader)).andExpect(serverOrReceiverFault());

    }

    @Test
    public void test_invalidGetAcksRequestWithoutMefHeader() throws Exception {

        mockClient.sendRequest(withSoapEnvelope(getAcksRequestWithoutMefHeader)).andExpect(serverOrReceiverFault());

    }

}