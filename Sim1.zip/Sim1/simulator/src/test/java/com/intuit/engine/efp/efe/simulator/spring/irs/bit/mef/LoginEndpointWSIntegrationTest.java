package com.intuit.engine.efp.efe.simulator.spring.irs.bit.mef;

import static org.springframework.ws.test.server.RequestCreators.withSoapEnvelope;
import static org.springframework.ws.test.server.ResponseMatchers.noFault;
import static org.springframework.ws.test.server.ResponseMatchers.xpath;

import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.soap.security.xwss.XwsSecurityInterceptor;
import org.springframework.ws.soap.security.xwss.callback.KeyStoreCallbackHandler;
import org.springframework.ws.test.server.MockWebServiceClient;
import org.springframework.xml.transform.StringResult;
import org.springframework.xml.transform.StringSource;

import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.LoginRequestType;
import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.LoginResponseType;
import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.MeFHeaderType;
import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.SessionKeyCdType;
import com.intuit.engine.efp.efe.agency.format.irs.bit.mef.generated.TestCdType;
import com.intuit.engine.efp.efe.simulator.irs.bit.mef.LoginService;

/**
 * @see LoginEndpoint
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class LoginEndpointWSIntegrationTest {

    private static final String NAMESPACE_URI = "http://www.irs.gov/a2a/mef/MeFMSIServices.xsd";

    private static final String MEFHEADER_NAME = "{http://www.irs.gov/a2a/mef/MeFHeader.xsd}MeFHeader";

    @Autowired
    private Jaxb2Marshaller jaxb2Marshaller;

    @Autowired
    private XwsSecurityInterceptor securityInterceptor;

    @LocalServerPort
    private int port = 0;


    /**
     * @see LoginEndpoint#login(MeFHeaderType, LoginRequestType)
     */
    @Ignore
    @Test
    public void login() throws IOException {
        WebServiceTemplate ws = new WebServiceTemplate(jaxb2Marshaller);
        ws.setInterceptors(new ClientInterceptor[]{securityInterceptor});
        JAXBElement<?> request = new JAXBElement<>(new QName(NAMESPACE_URI, "LoginRequest"), LoginRequestType.class, new LoginRequestType());

        LoginResponseType loginResponse = new LoginResponseType();
        loginResponse.setStatusTxt("Login Successful");
        StringResult result = new StringResult();
        JAXBElement<LoginResponseType> jaxbElement = new JAXBElement<>(new QName(NAMESPACE_URI, "LoginResponse"), LoginResponseType.class, loginResponse);
        jaxb2Marshaller.marshal(jaxbElement, result);
        System.out.print(result);

        ws.marshalSendAndReceive("http://localhost:" + port + "/a2a/mef/login", request, m -> {
            if (m instanceof SaajSoapMessage) {
                SaajSoapMessage message = (SaajSoapMessage) m;
                message.getSaajMessage();
                SoapHeader soapHeader = message.getSoapHeader();
                MeFHeaderType meFHeader = new MeFHeaderType();
                meFHeader.setMessageID("11111201920750000001");
                meFHeader.setAction("Login");
                try {
                    meFHeader.setMessageTs(DatatypeFactory.newInstance().newXMLGregorianCalendar(Instant.now().toString()));
                } catch (DatatypeConfigurationException e) {
                    // ignore, just don't set the date;
                }
                meFHeader.setETIN("11111");
                meFHeader.setSessionKeyCd(SessionKeyCdType.Y);
                meFHeader.setTestCd(TestCdType.P);
                meFHeader.setAppSysID("44445507");
                meFHeader.setWSDLVersionNum("10.2");
                jaxb2Marshaller.marshal(new JAXBElement<>(QName.valueOf(MEFHEADER_NAME), MeFHeaderType.class, meFHeader), soapHeader.getResult());
            }
        });
    }

}